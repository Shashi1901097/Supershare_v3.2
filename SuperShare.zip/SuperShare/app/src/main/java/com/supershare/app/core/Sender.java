package com.supershare.app.core;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Sends files. It logs in with the code, asks the receiver what it already has and whether the rest fits into
 * its free space, then sends only the missing 4 MB chunks over several parallel encrypted streams.
 */
public final class Sender {
    public static final long STALL_NANOS = 30_000_000_000L;

    public static final class Result {
        /** True when nothing is left to send (everything stored, or already there). */
        public final boolean complete;
        /** Ids of files the receiver has no room for. */
        public final List<String> blockedIds;
        public final int haveCount;
        public final long needMore;
        public final long receiverFree;

        Result(boolean complete, List<String> blockedIds, int haveCount, long needMore, long receiverFree) {
            this.complete = complete; this.blockedIds = blockedIds; this.haveCount = haveCount;
            this.needMore = needMore; this.receiverFree = receiverFree;
        }
    }

    /** Progress of one single file (bytes safely on the receiver, of its size). */
    public interface FileProgress { void onFile(String id, long sent, long size); }

    /** Thrown inside a worker when the user cancelled the file it was sending. */
    private static final class Skipped extends IOException {
        final String id;
        Skipped(String id) { super("File cancelled"); this.id = id; }
    }

    /** Everything the worker threads of one send share. */
    private static final class Run {
        String host; int port; byte[] sid, key;
        long total;
        final AtomicLong sent = new AtomicLong();
        Progress progress; FileProgress fp;
        final Map<String, AtomicLong> per = new ConcurrentHashMap<>();
        final Map<String, Long> sizes = new ConcurrentHashMap<>();
        Set<String> skip;
        final Set<String> notified = Collections.newSetFromMap(new ConcurrentHashMap<>());
        AtomicBoolean cancel;
        final AtomicLong lastMove = new AtomicLong(System.nanoTime());
        final Set<Closeable> live = Collections.newSetFromMap(new ConcurrentHashMap<>());
        final AtomicBoolean abort = new AtomicBoolean(false);

        /** Overall progress without the files the user cancelled. */
        void report() {
            long cut = 0, cutTotal = 0;
            for (String id : skip) {
                AtomicLong a = per.get(id);
                Long sz = sizes.get(id);
                if (a != null && sz != null) { cut += a.get(); cutTotal += sz; }
            }
            progress.onProgress(Math.max(0, sent.get() - cut), Math.max(0, total - cutTotal));
        }
    }

    private static final class Reply {
        long free;
        byte[] status;
        long[] need;
        BitSet[] bits;
    }

    private static final class Task {
        final Source src; final int start; final int count; final long bytes;
        Task(Source src, int start, int count) {
            this.src = src; this.start = start; this.count = count;
            this.bytes = Math.min((long) count * Protocol.CHUNK, src.size() - (long) start * Protocol.CHUNK);
        }
    }

    private Sender() {}

    public static Result send(String host, int port, String code, List<? extends Source> files,
                              Progress progress, AtomicBoolean cancel) throws IOException {
        return send(host, port, code, files, progress, cancel, Protocol.BIG_STREAMS);
    }

    /** maxStreams: parallel connections per big file (use fewer when sending to several phones at once). */
    public static Result send(String host, int port, String code, List<? extends Source> files,
                              Progress progress, AtomicBoolean cancel, int maxStreams) throws IOException {
        return send(host, port, code, files, progress, cancel, maxStreams, Collections.<String>emptySet(), null);
    }

    /**
     * skip: ids of files the user cancelled. It may grow while sending (use a concurrent set); a file added to it
     * stops at once, the receiver is told to delete its partial copy, and it no longer counts in the progress.
     * fp (optional) gets the progress of each single file.
     */
    public static Result send(String host, int port, String code, List<? extends Source> all,
                              Progress progress, AtomicBoolean cancel, int maxStreams,
                              Set<String> skip, FileProgress fp) throws IOException {
        if (maxStreams < 1) maxStreams = 1;
        if (!Keys.isValid(code)) throw new IOException("Invalid code");
        List<Source> files = new ArrayList<>();
        for (Source s : all) if (!skip.contains(s.id())) files.add(s);
        if (files.isEmpty()) return new Result(true, new ArrayList<String>(), 0, 0, 0);
        long total = 0;
        for (Source s : files) {
            if (s.size() < 0) throw new IOException("Bad file size: " + s.name());
            total += s.size();
        }
        SecureRandom rnd = new SecureRandom();
        Reply q;
        final Run run = new Run();
        try (Link link = login(host, port, code, rnd)) {
            run.sid = link.sessionId;
            run.key = link.sessionKey;
            q = query(link, files);
        }
        run.host = host; run.port = port; run.total = total; run.progress = progress; run.fp = fp;
        run.skip = skip; run.cancel = cancel;

        long already = 0;
        for (int i = 0; i < files.size(); i++) {
            Source f = files.get(i);
            if (q.status[i] == Protocol.S_SKIP) {               // the receiver cancelled this file: forget it
                run.total -= f.size();
                if (fp != null) fp.onFile(f.id(), -1, f.size());
                continue;
            }
            long d = Protocol.doneBytes(q.bits[i], f.size());
            already += d;
            run.per.put(f.id(), new AtomicLong(d));
            run.sizes.put(f.id(), f.size());
            if (fp != null) fp.onFile(f.id(), d, f.size());
        }
        run.sent.set(already);
        run.report();

        List<Task> tasks = new ArrayList<>();
        List<String> blocked = new ArrayList<>();
        int have = 0;
        long needMore = 0;
        for (int i = 0; i < files.size(); i++) {
            Source f = files.get(i);
            if (q.status[i] == Protocol.S_SKIP) continue;
            if (q.status[i] == Protocol.S_NO_SPACE) {
                blocked.add(f.id());
                needMore = Math.max(needMore, q.need[i]);
                continue;
            }
            if (q.status[i] == Protocol.S_HAVE) { have++; continue; }
            int chunks = Protocol.chunksOf(f.size());
            BitSet bits = q.bits[i];
            int c = bits.nextClearBit(0);
            while (c < chunks) {
                int next = bits.nextSetBit(c);
                int e = (next < 0 || next > chunks) ? chunks : next;
                int runChunks = e - c;
                long runBytes = Math.min((long) runChunks * Protocol.CHUNK, f.size() - (long) c * Protocol.CHUNK);
                int pieces = runBytes > Protocol.SPLIT_ABOVE ? Math.min(maxStreams, runChunks) : 1;
                int per = (runChunks + pieces - 1) / pieces;
                int x = c;
                while (x < e) { int k = Math.min(per, e - x); tasks.add(new Task(f, x, k)); x += k; }
                c = bits.nextClearBit(e);
            }
        }
        if (!tasks.isEmpty()) runTasks(run, tasks);
        // A file cancelled while we were still announcing / connecting: make sure the receiver drops it too.
        for (Source f : files) if (skip.contains(f.id())) notifyCancel(run, f.id());
        return new Result(blocked.isEmpty(), blocked, have, needMore, q.free);
    }

    private static Link login(String host, int port, String code, SecureRandom rnd) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), 8000);
            s.setSoTimeout(15000);
            return Handshake.clientQuery(s, code, rnd);
        } catch (IOException | RuntimeException e) {
            try { s.close(); } catch (IOException ignored) {}
            throw e;
        }
    }

    private static Reply query(Link link, List<? extends Source> files) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(bo);
        o.writeInt(files.size());
        for (Source f : files) { o.writeUTF(f.id()); o.writeUTF(f.name()); o.writeLong(f.size()); }
        if (bo.size() > Protocol.MAX_QUERY_PLAIN) throw new IOException("Too many files in one batch");
        link.send(bo.toByteArray(), 0, bo.size());

        byte[] plain;
        try { plain = link.recv(Protocol.MAX_QUERY_PLAIN); }
        catch (java.io.EOFException e) { throw new IOException("Receiver refused the request"); }
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(plain));
        Reply r = new Reply();
        r.free = in.readLong();
        int n = in.readInt();
        if (n != files.size()) throw new IOException("Unexpected reply from receiver");
        r.status = new byte[n]; r.need = new long[n]; r.bits = new BitSet[n];
        for (int i = 0; i < n; i++) {
            r.status[i] = in.readByte();
            r.need[i] = in.readLong();
            int len = in.readInt();
            if (len < 0 || len > (Protocol.MAX_FILE_SIZE / Protocol.CHUNK / 8) + 16 || len > in.available())
                throw new IOException("Bad reply");
            byte[] b = new byte[len];
            in.readFully(b);
            r.bits[i] = BitSet.valueOf(b);
        }
        return r;
    }

    private static void runTasks(Run run, List<Task> tasks) throws IOException {
        Collections.sort(tasks, (a, b) -> Long.compare(b.bytes, a.bytes));
        final ExecutorService pool = Executors.newFixedThreadPool(Math.min(Protocol.MAX_THREADS, tasks.size()));
        final ScheduledExecutorService dog = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "sender-watchdog");
            t.setDaemon(true);
            return t;
        });
        dog.scheduleWithFixedDelay(() -> {
            if (run.cancel.get() || System.nanoTime() - run.lastMove.get() > STALL_NANOS) { run.abort.set(true); closeAll(run.live); }
        }, 1, 1, TimeUnit.SECONDS);
        try {
            List<Future<Void>> fs = new ArrayList<>();
            for (final Task t : tasks) {
                fs.add(pool.submit((Callable<Void>) () -> {
                    sendTask(run, t);
                    return null;
                }));
            }
            for (Future<Void> f : fs) {
                try { f.get(); }
                catch (ExecutionException e) {
                    Throwable c = e.getCause();
                    if (c instanceof Skipped) {                      // only this file stops; the others go on
                        notifyCancel(run, ((Skipped) c).id);
                        continue;
                    }
                    run.abort.set(true); closeAll(run.live);
                    if (run.cancel.get()) throw new IOException("Cancelled");
                    if (c instanceof IOException) throw (IOException) c;
                    throw new IOException(String.valueOf(c));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    run.abort.set(true); closeAll(run.live);
                    throw new IOException("Interrupted");
                }
            }
        } finally {
            dog.shutdownNow();
            pool.shutdownNow();
        }
    }

    private static void closeAll(Set<Closeable> live) {
        for (Closeable c : live) { try { c.close(); } catch (IOException ignored) {} }
    }

    /** Tells the receiver (once per file) to throw away what it already has of a cancelled file. Best effort. */
    private static void notifyCancel(Run run, String id) {
        if (!run.sizes.containsKey(id) || !run.notified.add(id)) return;
        try (Socket s = new Socket()) {
            s.connect(new InetSocketAddress(run.host, run.port), 5000);
            s.setSoTimeout(8000);
            Link link = Handshake.clientData(s, run.sid, run.key, Protocol.T_CANCEL);
            ByteArrayOutputStream hb = new ByteArrayOutputStream();
            new DataOutputStream(hb).writeUTF(id);
            link.send(hb.toByteArray(), 0, hb.size());
            byte[] ack = new byte[1 + 16];
            link.recv(ack, 1);
        } catch (IOException | RuntimeException ignored) { /* the receiver keeps a partial copy it can discard itself */ }
        run.report();
        FileProgress fp = run.fp;
        if (fp != null) { Long sz = run.sizes.get(id); if (sz != null) fp.onFile(id, 0, sz); }
    }

    private static void sendTask(Run run, Task t) throws IOException {
        final String fid = t.src.id();
        if (run.skip.contains(fid)) throw new Skipped(fid);          // cancelled before it even started
        try (Opened o = t.src.open(); Socket s = new Socket()) {
            run.live.add(s);
            try {
                s.setTcpNoDelay(true);
                try { s.setSendBufferSize(8 << 20); } catch (java.net.SocketException ignored) {}
                s.connect(new InetSocketAddress(run.host, run.port), 8000);
                s.setSoTimeout(15000);
                Link link = Handshake.clientData(s, run.sid, run.key);

                ByteArrayOutputStream hb = new ByteArrayOutputStream();
                DataOutputStream h = new DataOutputStream(hb);
                h.writeUTF(fid);
                h.writeInt(t.start);
                h.writeInt(t.count);
                link.send(hb.toByteArray(), 0, hb.size());

                FileChannel fc = o.channel();
                long pos = (long) t.start * Protocol.CHUNK;
                long end = pos + t.bytes;
                ByteBuffer bb = ByteBuffer.allocate(Protocol.DATA_FRAME);
                byte[] arr = bb.array();
                AtomicLong mine = run.per.get(fid);
                long fileSize = t.src.size();
                while (pos < end) {
                    if (run.skip.contains(fid)) throw new Skipped(fid);
                    if (run.cancel.get() || run.abort.get()) throw new IOException("Cancelled");
                    int want = (int) Math.min(Protocol.DATA_FRAME, end - pos);
                    bb.clear();
                    bb.limit(want);
                    int got = 0;
                    while (bb.hasRemaining()) {
                        int r = fc.read(bb, pos + got);
                        if (r < 0) throw new IOException("File ended early: " + t.src.name());
                        got += r;
                    }
                    link.send(arr, 0, want);
                    pos += want;
                    run.lastMove.set(System.nanoTime());
                    run.sent.addAndGet(want);
                    long mineNow = mine.addAndGet(want);
                    run.report();
                    if (run.fp != null) run.fp.onFile(fid, Math.min(mineNow, fileSize), fileSize);
                }
                s.setSoTimeout(60000);
                byte[] ack = new byte[1 + 16];
                int n;
                try { n = link.recv(ack, 1); }
                catch (java.net.SocketTimeoutException e) { throw new IOException("Receiver did not confirm"); }
                if (n != 1 || ack[0] != 1) throw new IOException("Receiver did not confirm the data");
            } finally {
                run.live.remove(s);
            }
        }
    }
}
