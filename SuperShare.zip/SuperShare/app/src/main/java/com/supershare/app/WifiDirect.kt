package com.supershare.app

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import androidx.core.content.ContextCompat
import com.supershare.app.core.Keys

/**
 * Wi-Fi Direct without any internet.
 *
 * Android 10+: the group owner creates a private group whose name and password come from the pairing code
 * (5 GHz when possible); the other phone joins it directly.
 * Android 7-9 cannot choose the group name, so the group owner creates a normal group with a random name,
 * reports it through [onGroupInfo] (it goes into the QR code) and the other phone joins it as a normal Wi-Fi network.
 *
 * [onConnected] gets the IP address of the group owner (the phone that creates the group).
 */
@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class WifiDirect(
    private val ctx: Context,
    private val onConnected: (String?) -> Unit,
    private val onStatus: (String) -> Unit,
    private val onGroupInfo: (String, String) -> Unit = { _, _ -> }
) {
    private val mgr = ctx.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val ch = mgr.initialize(ctx, ctx.mainLooper, null)
    private val main = Handler(ctx.mainLooper)
    private var registered = false
    @Volatile private var stopped = false

    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION) {
                mgr.requestConnectionInfo(ch) { if (it.groupFormed) onConnected(it.groupOwnerAddress?.hostAddress) }
            }
        }
    }

    private fun register() {
        if (registered) return
        ContextCompat.registerReceiver(ctx, rx,
            IntentFilter(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED)
        registered = true
    }

    private class Listener(val ok: () -> Unit = {}, val fail: (Int) -> Unit = {}) : WifiP2pManager.ActionListener {
        override fun onSuccess() = ok()
        override fun onFailure(reason: Int) = fail(reason)
    }

    /** The phone that creates the group (the receiver, or the sender of a group share). */
    fun host(keys: Keys) {
        register()
        // Clear anything left over from an earlier attempt or another app: that is what makes Wi-Fi Direct report "busy".
        try { mgr.stopPeerDiscovery(ch, null) } catch (e: Exception) { }
        try { mgr.cancelConnect(ch, null) } catch (e: Exception) { }
        mgr.removeGroup(ch, Listener({ main.postDelayed({ start(keys) }, 700) }, { main.postDelayed({ start(keys) }, 700) }))
    }

    private fun start(keys: Keys) {
        if (stopped) return
        if (Build.VERSION.SDK_INT >= 29) create(keys, WifiP2pConfig.GROUP_OWNER_BAND_5GHZ, 0) else createLegacy(0)
    }

    private fun failText(r: Int) =
        "Could not start Wi-Fi Direct (code $r). Turn off Hotspot and other Wi-Fi Direct apps, switch Wi-Fi off and on, then try again."

    /** Group with our own name and password. Some phones refuse it or are busy: retry, then use a normal group. */
    private fun create(keys: Keys, band: Int, attempt: Int) {
        if (stopped) return
        val cfg = WifiP2pConfig.Builder()
            .setNetworkName(keys.wifiName)
            .setPassphrase(keys.wifiPass)
            .enablePersistentMode(false)
            .setGroupOperatingBand(band)
            .build()
        mgr.createGroup(ch, cfg, Listener(
            { onStatus("Ready. Waiting for the QR code to be scanned.") },
            { r ->
                when {
                    band != WifiP2pConfig.GROUP_OWNER_BAND_AUTO ->                    // 5 GHz not possible now: any band
                        main.postDelayed({ create(keys, WifiP2pConfig.GROUP_OWNER_BAND_AUTO, 0) }, 600)
                    r == WifiP2pManager.BUSY && attempt < 2 ->                         // busy: clear and try again
                        mgr.removeGroup(ch, Listener(
                            { main.postDelayed({ create(keys, band, attempt + 1) }, 900) },
                            { main.postDelayed({ create(keys, band, attempt + 1) }, 900) }))
                    else -> {                                                          // the phone refuses custom names: plain group
                        onStatus("Starting in compatibility mode…")
                        createLegacy(0)
                    }
                }
            }))
    }

    /** Plain group with a name chosen by the phone; the name and password travel inside the QR code. */
    private fun createLegacy(attempt: Int) {
        if (stopped) return
        mgr.createGroup(ch, Listener({ readGroup(0) }, { r ->
            if (attempt < 3) {
                mgr.removeGroup(ch, Listener(
                    { main.postDelayed({ createLegacy(attempt + 1) }, 1200) },
                    { main.postDelayed({ createLegacy(attempt + 1) }, 1200) }))
            } else onStatus(failText(r))
        }))
    }

    /** The new group needs a moment before its name and password can be read. */
    private fun readGroup(tries: Int) {
        if (stopped) return
        mgr.requestGroupInfo(ch) { g ->
            val ssid = g?.networkName
            val pass = g?.passphrase
            if (!ssid.isNullOrEmpty() && !pass.isNullOrEmpty()) {
                onGroupInfo(ssid, pass)
                onStatus("Ready. Waiting for the QR code to be scanned.")
            } else if (tries < 20) main.postDelayed({ readGroup(tries + 1) }, 500)
            else onStatus("Could not read the Wi-Fi Direct group. Turn Wi-Fi off and on, then try again.")
        }
    }

    /** The phone that joins the group of the other phone. */
    fun join(ssid: String, pass: String) {
        register()
        if (Build.VERSION.SDK_INT >= 29) {
            val cfg = WifiP2pConfig.Builder().setNetworkName(ssid).setPassphrase(pass).build()
            mgr.connect(ch, cfg, Listener({
                onStatus("Connecting…")
                // If the link was already up no new broadcast arrives, so ask for it explicitly.
                main.postDelayed({ mgr.requestConnectionInfo(ch) { if (it.groupFormed) onConnected(it.groupOwnerAddress?.hostAddress) } }, 2500)
            }, { r -> onStatus("Could not connect (code $r). Scan the QR code again and make sure the other phone is waiting.") }))
        } else joinLegacy(ssid, pass)
    }

    private fun joinLegacy(ssid: String, pass: String) {
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val quoted = "\"$ssid\""
        val conf = WifiConfiguration().apply {
            SSID = quoted
            preSharedKey = "\"$pass\""
            allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK)
        }
        var id = wm.addNetwork(conf)
        if (id < 0) id = try { wm.configuredNetworks?.firstOrNull { it.SSID == quoted }?.networkId ?: -1 } catch (e: Exception) { -1 }
        if (id < 0) { onStatus("Could not join the other phone's Wi-Fi. Scan the QR code again."); return }
        onStatus("Connecting…")
        wm.disconnect()
        wm.enableNetwork(id, true)
        wm.reconnect()
        waitForLink(wm, quoted, 0)
    }

    private fun waitForLink(wm: WifiManager, quoted: String, tries: Int) {
        if (stopped) return
        val info = try { wm.connectionInfo } catch (e: Exception) { null }
        val gw = try { wm.dhcpInfo?.serverAddress ?: 0 } catch (e: Exception) { 0 }
        if (info != null && info.ssid == quoted && gw != 0) {
            onConnected("${gw and 0xff}.${(gw shr 8) and 0xff}.${(gw shr 16) and 0xff}.${(gw shr 24) and 0xff}")
        } else if (tries < 60) main.postDelayed({ waitForLink(wm, quoted, tries + 1) }, 500)
        else onStatus("Could not connect. Scan the QR code again and make sure the other phone is waiting.")
    }

    fun stop() {
        stopped = true
        if (registered) {
            try { ctx.unregisterReceiver(rx) } catch (e: Exception) { }
        }
        registered = false
        main.removeCallbacksAndMessages(null)
        mgr.removeGroup(ch, null)
    }
}
