package com.supershare.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel

private fun encode(text: String): BitMatrix? = try {
    val hints = mapOf<EncodeHintType, Any>(
        EncodeHintType.MARGIN to 0,
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.M
    )
    QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, hints)
} catch (e: Exception) { null }

/** A QR code drawn black on white (always, so that every scanner can read it, also in dark mode). */
@Composable
fun QrImage(text: String, dim: Dp) {
    val matrix = remember(text) { encode(text) }
    Box(Modifier.size(dim).clip(RoundedCornerShape(18.dp)).background(Color.White).padding(14.dp)) {
        val m = matrix
        if (m != null) {
            Canvas(Modifier.fillMaxSize()) {
                val n = m.width
                val cell = size.minDimension / n
                for (y in 0 until n) {
                    for (x in 0 until n) {
                        if (m.get(x, y)) drawRect(Color.Black, topLeft = Offset(x * cell, y * cell), size = Size(cell + 0.6f, cell + 0.6f))
                    }
                }
            }
        }
    }
}
