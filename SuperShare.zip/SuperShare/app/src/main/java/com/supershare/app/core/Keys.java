package com.supershare.app.core;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * The pairing code is 8 random characters (letters, digits and special characters). Nobody types it: it travels
 * inside a QR code that one phone shows and the other phone scans. It is only used (1) to name/lock the private
 * Wi-Fi Direct group, which merely controls who can join, and (2) as the password of the SRP key exchange, which
 * protects the files. Because of SRP a captured conversation cannot be used to guess the code offline.
 */
public final class Keys {
    public static final int CODE_LEN = 8;
    public static final int ITERATIONS = 10_000;
    static final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    static final String DIGITS = "0123456789";
    static final String SPECIAL = "!@#$%&*+=?-_";
    static final String ALPHABET = LETTERS + DIGITS + SPECIAL;
    private static final String QR_PREFIX = "SS1";
    /** QR shown by a receiver that waits for ONE sender (the sender scans it). */
    public static final char QR_RECEIVER = 'R';
    /** QR shown by the sender of a GROUP share (every receiver scans it). */
    public static final char QR_GROUP = 'G';
    private static final byte[] SALT = "SuperShare/v2/wifi".getBytes(StandardCharsets.UTF_8);
    private static final SecureRandom RND = new SecureRandom();

    public final String wifiName;
    public final String wifiPass;

    private Keys(String wifiName, String wifiPass) {
        this.wifiName = wifiName;
        this.wifiPass = wifiPass;
    }

    /** 8 random characters with at least one letter, one digit and one special character. */
    public static String newCode() {
        while (true) {
            StringBuilder b = new StringBuilder(CODE_LEN);
            for (int i = 0; i < CODE_LEN; i++) b.append(ALPHABET.charAt(RND.nextInt(ALPHABET.length())));
            String c = b.toString();
            if (hasAll(c)) return c;
        }
    }

    private static boolean hasAll(String c) {
        boolean l = false, d = false, s = false;
        for (int i = 0; i < c.length(); i++) {
            char ch = c.charAt(i);
            if (LETTERS.indexOf(ch) >= 0) l = true;
            else if (DIGITS.indexOf(ch) >= 0) d = true;
            else if (SPECIAL.indexOf(ch) >= 0) s = true;
        }
        return l && d && s;
    }

    public static boolean isValid(String code) {
        if (code == null || code.length() != CODE_LEN) return false;
        for (int i = 0; i < code.length(); i++) if (ALPHABET.indexOf(code.charAt(i)) < 0) return false;
        return true;
    }

    /** The text put into a QR code: "SS1:R:code" (receiver shows it) or "SS1:G:code" (group sender shows it). */
    public static String toQr(char kind, String code) {
        if (!isValid(code) || (kind != QR_RECEIVER && kind != QR_GROUP)) throw new IllegalArgumentException("Invalid QR");
        return QR_PREFIX + ":" + kind + ":" + code;
    }

    /**
     * Same, plus the Wi-Fi name and password of the group. Only phones older than Android 10 need this: they cannot
     * choose the group name, so the group they create has a random one that the other phone must be told.
     */
    public static String toQr(char kind, String code, String ssid, String pass) {
        String base = toQr(kind, code);
        if (ssid == null || ssid.isEmpty() || pass == null || pass.length() < 8) return base;
        if (ssid.indexOf('\n') >= 0 || pass.indexOf('\n') >= 0) return base;
        return base + "\n" + ssid + "\n" + pass;
    }

    /** Reads scanned text. Returns {kind, code, ssid, pass} (ssid and pass are "" when absent) or null if it is not ours. */
    public static String[] fromQr(String raw) {
        if (raw == null) return null;
        String[] lines = raw.trim().split("\n", -1);
        if (lines.length != 1 && lines.length != 3) return null;
        String[] p = lines[0].trim().split(":", 3);
        if (p.length != 3 || !QR_PREFIX.equals(p[0]) || p[1].length() != 1) return null;
        char k = p[1].charAt(0);
        if ((k != QR_RECEIVER && k != QR_GROUP) || !isValid(p[2])) return null;
        String ssid = "", pass = "";
        if (lines.length == 3) {
            ssid = lines[1].trim(); pass = lines[2].trim();
            if (ssid.isEmpty() || ssid.length() > 32 || pass.length() < 8 || pass.length() > 63) return null;
        }
        return new String[]{p[1], p[2], ssid, pass};
    }

    public static Keys derive(String code) throws GeneralSecurityException {
        return derive(code, ITERATIONS);
    }

    public static Keys derive(String code, int iterations) throws GeneralSecurityException {
        if (!isValid(code)) throw new IllegalArgumentException("Invalid code");
        byte[] k = pbkdf2(code.getBytes(StandardCharsets.UTF_8), SALT, iterations, 20);
        return new Keys("DIRECT-SS-" + hex(k, 0, 4), hex(k, 4, 16));
    }

    /** PBKDF2-HMAC-SHA256 written out by hand: older Android versions do not offer it, and both phones must agree. */
    static byte[] pbkdf2(byte[] pw, byte[] salt, int iterations, int len) throws GeneralSecurityException {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(pw, "HmacSHA256"));
        byte[] out = new byte[len];
        int blocks = (len + 31) / 32;
        for (int b = 1; b <= blocks; b++) {
            mac.update(salt);
            mac.update(new byte[]{(byte) (b >>> 24), (byte) (b >>> 16), (byte) (b >>> 8), (byte) b});
            byte[] u = mac.doFinal();
            byte[] t = u.clone();
            for (int i = 1; i < iterations; i++) {
                u = mac.doFinal(u);
                for (int j = 0; j < t.length; j++) t[j] ^= u[j];
            }
            System.arraycopy(t, 0, out, (b - 1) * 32, Math.min(32, len - (b - 1) * 32));
        }
        return out;
    }

    private static String hex(byte[] b, int off, int len) {
        StringBuilder sb = new StringBuilder();
        for (int i = off; i < off + len; i++) sb.append(String.format("%02x", b[i]));
        return sb.toString();
    }
}
