package com.supershare.app

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.os.Build
import android.net.Uri
import android.provider.MediaStore
import android.provider.MediaStore.Files.FileColumns
import android.util.LruCache
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.supershare.app.core.Protocol
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------------------------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------------------------

/** One file (or installed app) the user can tick in the picker. [key] is unique (uri, path or "app:package"). */
class PickItem(
    val key: String, val uri: Uri, val name: String, val size: Long, val modified: Long,
    val kind: String,              // video, image, audio, app or file
    val folder: String = "",       // folder path, used by the Folders / Albums lists
    val pkg: String = ""
) {
    /** Same file (name + size + modified time) always gets the same id, so a transfer can be resumed. */
    val id: String by lazy { Protocol.fileId(name, size, modified) }
}

class FileLists(val docs: List<PickItem>, val ebooks: List<PickItem>, val archives: List<PickItem>, val big: List<PickItem>)

class Group(val path: String, val label: String, val items: List<PickItem>)

private val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv", "m4v", "ts", "mpg", "mpeg")
private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp")
private val AUDIO_EXT = setOf("mp3", "flac", "wav", "aac", "ogg", "m4a", "opus", "amr", "wma", "mid")
private val DOC_EXT = setOf("doc", "docx", "ppt", "pptx", "xls", "xlsx", "wps", "odt", "ods", "odp", "rtf", "csv", "key", "pages", "numbers")
private val EBOOK_EXT = setOf("pdf", "txt", "mobi", "umd", "ebk", "chm", "epub", "azw3", "fb2")
private val ARCHIVE_EXT = setOf("zip", "rar", "iso", "7z", "tar", "gz", "tgz", "bz2", "xz", "apk", "xapk", "apks")

fun kindOf(name: String): String {
    val e = name.substringAfterLast('.', "").lowercase()
    return when {
        e in VIDEO_EXT -> "video"
        e in IMAGE_EXT -> "image"
        e in AUDIO_EXT -> "audio"
        else -> "file"
    }
}

private fun safeName(s: String): String = s.map { if (it in "\\/:*?\"<>|") '_' else it }.joinToString("").trim().ifEmpty { "app" }

fun List<PickItem>.matching(q: String): List<PickItem> = if (q.isBlank()) this else filter { it.name.contains(q.trim(), ignoreCase = true) }

fun groupByFolder(list: List<PickItem>): List<Group> =
    list.groupBy { it.folder }.map { (path, items) ->
        Group(path, path.trimEnd('/').substringAfterLast('/').ifEmpty { "Other" }, items)
    }.sortedBy { it.label.lowercase() }

fun dateLabel(ms: Long): String {
    fun day(t: Long): Calendar = Calendar.getInstance().apply { timeInMillis = t; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
    val d = day(ms)
    val today = day(System.currentTimeMillis())
    val diff = Math.round((today.timeInMillis - d.timeInMillis) / 86_400_000.0)
    return when {
        diff == 0L -> "Today"
        diff == 1L -> "Yesterday"
        d.get(Calendar.YEAR) == today.get(Calendar.YEAR) -> SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(ms))
        else -> SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(ms))
    }
}

fun toggleItem(ui: UiState, p: PickItem) {
    if (p.key in ui.sel) ui.sel.remove(p.key) else ui.sel[p.key] = p
}

fun setMany(ui: UiState, items: List<PickItem>, on: Boolean) {
    for (p in items) if (on) ui.sel[p.key] = p else ui.sel.remove(p.key)
}

// ---------------------------------------------------------------------------------------------
// Loading from the phone (MediaStore). Run on a background thread.
// ---------------------------------------------------------------------------------------------

object MediaLoader {
    private const val BIG = 50L * 1024 * 1024

    fun media(ctx: Context, base: Uri, kind: String): List<PickItem> {
        val out = ArrayList<PickItem>()
        val legacy = Build.VERSION.SDK_INT < 29              // Android 7-9 have no RELATIVE_PATH
        val proj = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_MODIFIED,
            if (legacy) MediaStore.MediaColumns.DATA else MediaStore.MediaColumns.RELATIVE_PATH
        )
        try {
            ctx.contentResolver.query(base, proj, "${MediaStore.MediaColumns.SIZE} > 0", null,
                "${MediaStore.MediaColumns.DATE_MODIFIED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    out.add(PickItem(uri.toString(), uri, c.getString(1) ?: "file", c.getLong(2), c.getLong(3) * 1000L, kind,
                        if (legacy) (c.getString(4) ?: "").substringBeforeLast('/', "") else (c.getString(4) ?: "")))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    fun videos(ctx: Context) = media(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video")
    fun images(ctx: Context) = media(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image")
    fun audio(ctx: Context) = media(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, "audio")

    /** Documents, e-books, archives and files over 50 MB. Needs "access to all files" to see files of other apps. */
    fun files(ctx: Context): FileLists {
        val docs = ArrayList<PickItem>()
        val ebooks = ArrayList<PickItem>()
        val archives = ArrayList<PickItem>()
        val big = ArrayList<PickItem>()
        val base = MediaStore.Files.getContentUri("external")
        val proj = arrayOf(FileColumns._ID, FileColumns.DISPLAY_NAME, FileColumns.SIZE, FileColumns.DATE_MODIFIED)
        val sel = "${FileColumns.SIZE} > 0 AND ${FileColumns.MIME_TYPE} IS NOT NULL AND " +
            "(${FileColumns.MEDIA_TYPE} IN (0,6) OR ${FileColumns.SIZE} > ?)"
        try {
            ctx.contentResolver.query(base, proj, sel, arrayOf(BIG.toString()), "${FileColumns.DATE_MODIFIED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    val size = c.getLong(2)
                    val uri = ContentUris.withAppendedId(base, c.getLong(0))
                    val item = PickItem(uri.toString(), uri, name, size, c.getLong(3) * 1000L, kindOf(name))
                    val ext = name.substringAfterLast('.', "").lowercase()
                    when {
                        ext in DOC_EXT -> docs.add(item)
                        ext in EBOOK_EXT -> ebooks.add(item)
                        ext in ARCHIVE_EXT -> archives.add(item)
                    }
                    if (size >= BIG) big.add(item)
                }
            }
        } catch (e: Exception) { }
        return FileLists(docs, ebooks, archives, big)
    }

    /** Installed apps that have a launcher icon; sharing one sends its APK file. */
    fun apps(ctx: Context): List<PickItem> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<PickItem>()
        val seen = HashSet<String>()
        try {
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo?.applicationInfo ?: continue
                if (!seen.add(ai.packageName)) continue
                val path = ai.sourceDir ?: continue
                val file = File(path)
                if (!file.canRead() || file.length() <= 0L) continue
                val label = ri.loadLabel(pm).toString().ifBlank { ai.packageName }
                out.add(PickItem("app:" + ai.packageName, Uri.fromFile(file), safeName(label) + ".apk",
                    file.length(), file.lastModified(), "app", pkg = ai.packageName))
            }
        } catch (e: Exception) { }
        return out.sortedBy { it.name.lowercase() }
    }
}

// ---------------------------------------------------------------------------------------------
// Thumbnails (loaded lazily while scrolling, cached in memory)
// ---------------------------------------------------------------------------------------------

object Thumbs {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun load(ctx: Context, p: PickItem): Bitmap? {
        cache.get(p.key)?.let { return it }
        val bmp: Bitmap? = try {
            when (p.kind) {
                "app" -> ctx.packageManager.getApplicationIcon(p.pkg).toBitmap(112, 112)
                "image", "video" -> thumb(ctx, p)
                else -> null
            }
        } catch (e: Exception) { null }
        if (bmp != null) cache.put(p.key, bmp)
        return bmp
    }

    private fun thumb(ctx: Context, p: PickItem): Bitmap? {
        if (Build.VERSION.SDK_INT >= 29 && p.uri.scheme == "content") return ctx.contentResolver.loadThumbnail(p.uri, Size(256, 256), null)
        if (p.kind == "video") {
            val r = MediaMetadataRetriever()
            try { r.setDataSource(ctx, p.uri); return r.frameAtTime } finally { try { r.release() } catch (e: Exception) { } }
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(p.uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 512) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        return ctx.contentResolver.openInputStream(p.uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    }
}

@Composable
fun Thumb(p: PickItem, modifier: Modifier) {
    val ctx = LocalContext.current
    val wants = p.kind == "image" || p.kind == "video" || p.kind == "app"
    val bmp by produceState<ImageBitmap?>(null, p.key) {
        value = if (wants) withContext(Dispatchers.IO) { Thumbs.load(ctx, p)?.asImageBitmap() } else null
    }
    val b = bmp
    if (b != null) {
        Box(modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
            Image(bitmap = b, contentDescription = null, modifier = Modifier.fillMaxSize(),
                contentScale = if (p.kind == "app") ContentScale.Fit else ContentScale.Crop)
        }
    } else {
        val ext = p.name.substringAfterLast('.', "")
        val c = typeColor(ext)
        Box(modifier.background(c.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            when (p.kind) {
                "video" -> AppIcon("video", c, 26.dp)
                "image" -> AppIcon("photo", c, 26.dp)
                "audio" -> AppIcon("audio", c, 26.dp)
                "app" -> AppIcon("android", Color(0xFF3DDC97), 26.dp)
                else -> Text(ext.take(4).uppercase().ifEmpty { "FILE" }, style = MaterialTheme.typography.labelSmall,
                    color = c, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Screen
// ---------------------------------------------------------------------------------------------

@Composable
fun PickerScreen(ui: UiState, act: Actions) {
    Column(Modifier.fillMaxSize()) {
        if (ui.pickMode == "group") GroupTop(act) else PickTop(ui, act)
        PickTabs(ui)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (ui.pickTab) {
                0 -> AllFilesTab(ui, act)
                1 -> VideosTab(ui, act)
                2 -> AppsTab(ui)
                3 -> PhotosTab(ui, act)
                else -> AudioTab(ui, act)
            }
        }
        PickBar(ui, act)
    }
}

@Composable
private fun IconBox(kind: String, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        AppIcon(kind, MaterialTheme.colorScheme.onSurface, 24.dp)
    }
}

/** Group Share: back button, title and the Send | Receive toggle above the file picker. */
@Composable
private fun GroupTop(act: Actions) {
    Column(Modifier.fillMaxWidth().statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)).clickable { act.onPickClose() },
                contentAlignment = Alignment.Center) { AppIcon("back", MaterialTheme.colorScheme.onSurface, 22.dp) }
            Spacer(Modifier.width(14.dp))
            Text("Group Share", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        PillOptions(listOf("Send", "Receive"), 0, 46.dp) { if (it == 1) act.onGroupShare() }   // Send is already open
    }
}

@Composable
private fun PickTop(ui: UiState, act: Actions) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        if (ui.searching) {
            IconBox("back") { ui.searching = false; ui.pickQuery = "" }
            OutlinedTextField(
                value = ui.pickQuery, onValueChange = { ui.pickQuery = it }, singleLine = true,
                placeholder = { Text("Search files") }, shape = RoundedCornerShape(16.dp), colors = fieldColors(),
                modifier = Modifier.weight(1f).padding(horizontal = 4.dp)
            )
        } else {
            IconBox("close") { act.onPickClose() }
            Text("Select Files To Share", Modifier.weight(1f), textAlign = TextAlign.Center,
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            IconBox("search") { ui.searching = true }
        }
    }
}

@Composable
private fun PickTabs(ui: UiState) {
    val tabs = listOf("ALL FILES" to "file", "VIDEOS" to "video", "APPS" to "android", "PHOTOS" to "photo", "AUDIO" to "audio")
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainerLow)) {
        tabs.forEachIndexed { i, tab ->
            val on = ui.pickTab == i
            Column(
                Modifier.weight(1f).clickable { if (!on) { ui.pickTab = i; ui.pickSub = 0; ui.pickQuery = ""; ui.searching = false } }
                    .padding(top = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                AppIcon(tab.second, if (on) Pink else MaterialTheme.colorScheme.outline, 26.dp)
                Spacer(Modifier.height(4.dp))
                Text(tab.first, style = MaterialTheme.typography.labelSmall, maxLines = 1, fontSize = 10.sp,
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Box(Modifier.width(30.dp).height(3.dp).clip(RoundedCornerShape(2.dp)).then(if (on) Modifier.background(BrandBrush) else Modifier))
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun SubTabs(ui: UiState, a: String, b: String) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainerLow)) {
        listOf(a, b).forEachIndexed { i, label ->
            val on = ui.pickSub == i
            Box(Modifier.weight(1f).clickable { ui.pickSub = i }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold,
                    color = if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline)
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun PickBar(ui: UiState, act: Actions) {
    val n = ui.sel.size
    val total = ui.sel.values.sumOf { it.size }
    Row(
        Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainerLow).navigationBarsPadding()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            Modifier.width(78.dp).height(52.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceContainerHigh),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
        ) {
            Text("$n", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (n > 0) Text(fmtSize(total), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(16.dp))
                .background(if (n > 0) BrandBrush else SolidColor(MaterialTheme.colorScheme.surfaceContainerHigh))
                .clickable(enabled = n > 0) { act.onPickSend() },
            contentAlignment = Alignment.Center
        ) {
            Text("SEND", color = if (n > 0) Color.White else MaterialTheme.colorScheme.outline,
                fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Pieces shared by the tabs
// ---------------------------------------------------------------------------------------------

@Composable
private fun PickRow(ui: UiState, p: PickItem) {
    Row(
        Modifier.fillMaxWidth().clickable { toggleItem(ui, p) }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Thumb(p, Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(p.name, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(fmtSize(p.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Checkbox(checked = p.key in ui.sel, onCheckedChange = { toggleItem(ui, p) })
    }
}

@Composable
private fun SelDot(on: Boolean, modifier: Modifier) {
    Box(
        modifier.size(24.dp).clip(CircleShape)
            .then(if (on) Modifier.background(BrandBrush) else Modifier.background(Color.Black.copy(alpha = 0.35f)))
            .border(1.5.dp, Color.White, CircleShape),
        contentAlignment = Alignment.Center
    ) { if (on) AppIcon("check", Color.White, 16.dp) }
}

@Composable
private fun EmptyText(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(strokeWidth = 3.dp) }
}

@Composable
private fun NeedAccess(text: String, button: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(text, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(14.dp))
        SmallButton(button, onClick = onClick)
    }
}

@Composable
private fun FlatList(ui: UiState, list: List<PickItem>, empty: String, modifier: Modifier = Modifier) {
    if (list.isEmpty()) {
        if (ui.loadingPick) Loading() else EmptyText(empty)
        return
    }
    LazyColumn(modifier.fillMaxWidth()) {
        items(list, key = { it.key }) { p -> PickRow(ui, p) }
    }
}

@Composable
private fun FolderList(ui: UiState, groups: List<Group>, empty: String, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(setOf<String>()) }
    if (groups.isEmpty()) {
        if (ui.loadingPick) Loading() else EmptyText(empty)
        return
    }
    LazyColumn(modifier.fillMaxWidth()) {
        groups.forEach { g ->
            item(key = "g:" + g.path) {
                val all = g.items.all { it.key in ui.sel }
                Column {
                Row(
                    Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer)
                        .clickable { open = if (g.path in open) open - g.path else open + g.path }
                        .padding(start = 16.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AppIcon(if (g.path in open) "tridown" else "tri", MaterialTheme.colorScheme.onSurface, 22.dp)
                    Spacer(Modifier.width(10.dp))
                    Text("${g.label} (${g.items.size})", Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { setMany(ui, g.items, !all) }) { Text(if (all) "Deselect" else "Select All") }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
            if (g.path in open) items(g.items, key = { g.path + "|" + it.key }) { p -> PickRow(ui, p) }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------------------------

@Composable
private fun CategoryRow(icon: String, color: Color, title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(54.dp).clip(CircleShape).background(color.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
            AppIcon(icon, color, 28.dp)
        }
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(sub, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AllFilesTab(ui: UiState, act: Actions) {
    val q = ui.pickQuery
    when {
        ui.pickView == "browse" -> BrowseView(ui, act)
        ui.pickView != "home" -> {
            val title = when (ui.pickView) { "docs" -> "Documents"; "ebooks" -> "EBooks"; "archives" -> "Archives"; else -> "Big Files" }
            val list = when (ui.pickView) { "docs" -> ui.docs; "ebooks" -> ui.ebooks; "archives" -> ui.archives; else -> ui.big }
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().clickable { ui.pickView = "home"; ui.pickQuery = "" }.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    AppIcon("back", MaterialTheme.colorScheme.onSurface, 22.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                FlatList(ui, remember(list, q) { list.matching(q) }, "No files here", Modifier.weight(1f))
            }
        }
        q.isNotBlank() -> {
            val all = remember(ui.docs, ui.ebooks, ui.archives, ui.big, q) {
                (ui.docs + ui.ebooks + ui.archives + ui.big).distinctBy { it.key }.matching(q)
            }
            FlatList(ui, all, "No matching files")
        }
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            if (!ui.allFiles) {
                Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceContainer).padding(16.dp)) {
                    Text("Allow access to all files to see documents, archives, big files and the whole storage.",
                        style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    SmallButton("Allow access") { act.onAllFilesAccess() }
                }
            }
            Spacer(Modifier.height(6.dp))
            CategoryRow("folder", Color(0xFF8E9AE6), "Internal Storage",
                "${fmtSize(ui.storageUsed)} / ${fmtSize(ui.storageTotal)}") { act.onBrowseRoot() }
            CategoryRow("file", Color(0xFF5B9DFF), "Documents(${ui.docs.size})", "doc, ppt, xls, wps, etc.") { ui.pickView = "docs" }
            CategoryRow("file", Color(0xFFFF6B6B), "EBooks(${ui.ebooks.size})", "pdf, txt, mobi, umd, ebk, chm, etc.") { ui.pickView = "ebooks" }
            CategoryRow("file", Color(0xFFFFB020), "Archives(${ui.archives.size})", "zip, rar, iso, 7z, apk, etc.") { ui.pickView = "archives" }
            CategoryRow("file", Color(0xFF3DDC97), "Big Files(${ui.big.size})", "files > 50 MB") { ui.pickView = "big" }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun BrowseView(ui: UiState, act: Actions) {
    val shown = remember(ui.browseEntries, ui.pickQuery) {
        if (ui.pickQuery.isBlank()) ui.browseEntries else ui.browseEntries.filter { it.name.contains(ui.pickQuery.trim(), ignoreCase = true) }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).clickable { act.onBrowseUp() }, contentAlignment = Alignment.Center) {
                AppIcon("back", MaterialTheme.colorScheme.onSurface, 22.dp)
            }
            Text(ui.browsePath.removePrefix("/storage/emulated/0").ifEmpty { "Internal storage" }, Modifier.weight(1f),
                style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            TextButton(onClick = {
                val files = shown.filter { !it.dir }.map { it.toPick() }
                setMany(ui, files, !files.all { it.key in ui.sel })
            }) { Text("Select all here") }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        if (shown.isEmpty()) {
            EmptyText("This folder is empty")
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(shown, key = { it.path }) { e ->
                    if (e.dir) {
                        Row(Modifier.fillMaxWidth().clickable { act.onBrowseOpen(e.path) }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            FileBadge(e.name, true)
                            Spacer(Modifier.width(14.dp))
                            Text(e.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                            AppIcon("forward", MaterialTheme.colorScheme.onSurfaceVariant, 20.dp)
                        }
                    } else PickRow(ui, e.toPick())
                }
            }
        }
    }
}

private fun BrowseEntry.toPick() = PickItem(path, Uri.fromFile(File(path)), name, size, modified, kindOf(name))

@Composable
private fun VideosTab(ui: UiState, act: Actions) {
    if (!ui.mediaOk) { NeedAccess("Allow access to videos, photos and audio to choose them here.", "Allow access") { act.onMediaAccess() }; return }
    val list = remember(ui.videos, ui.pickQuery) { ui.videos.matching(ui.pickQuery) }
    Column(Modifier.fillMaxSize()) {
        SubTabs(ui, "VIDEOS", "FOLDERS")
        if (ui.pickSub == 0) FlatList(ui, list, "No videos found", Modifier.weight(1f))
        else FolderList(ui, remember(list) { groupByFolder(list) }, "No videos found", Modifier.weight(1f))
    }
}

@Composable
private fun AudioTab(ui: UiState, act: Actions) {
    if (!ui.mediaOk) { NeedAccess("Allow access to videos, photos and audio to choose them here.", "Allow access") { act.onMediaAccess() }; return }
    val list = remember(ui.audios, ui.pickQuery) { ui.audios.matching(ui.pickQuery) }
    Column(Modifier.fillMaxSize()) {
        SubTabs(ui, "AUDIO", "FOLDERS")
        if (ui.pickSub == 0) FlatList(ui, list, "No audio found", Modifier.weight(1f))
        else FolderList(ui, remember(list) { groupByFolder(list) }, "No audio found", Modifier.weight(1f))
    }
}

@Composable
private fun AppsTab(ui: UiState) {
    FlatList(ui, remember(ui.apps, ui.pickQuery) { ui.apps.matching(ui.pickQuery) }, "No apps found")
}

@Composable
private fun PhotosTab(ui: UiState, act: Actions) {
    if (!ui.mediaOk) { NeedAccess("Allow access to videos, photos and audio to choose them here.", "Allow access") { act.onMediaAccess() }; return }
    val list = remember(ui.images, ui.pickQuery) { ui.images.matching(ui.pickQuery) }
    Column(Modifier.fillMaxSize()) {
        SubTabs(ui, "PHOTOS", "ALBUMS")
        if (ui.pickSub == 1) {
            FolderList(ui, remember(list) { groupByFolder(list) }, "No photos found", Modifier.weight(1f))
        } else if (list.isEmpty()) {
            Box(Modifier.weight(1f)) { if (ui.loadingPick) Loading() else EmptyText("No photos found") }
        } else {
            val byDate = remember(list) { list.groupBy { dateLabel(it.modified) } }
            LazyVerticalGrid(
                columns = GridCells.Fixed(4), modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(bottom = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                byDate.forEach { (label, group) ->
                    item(key = "d:$label", span = { GridItemSpan(maxLineSpan) }) {
                        val all = group.all { it.key in ui.sel }
                        Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceContainer).padding(start = 14.dp, end = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("$label (${group.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { setMany(ui, group, !all) }) { Text(if (all) "Deselect" else "Select All") }
                        }
                    }
                    items(group, key = { it.key }) { p ->
                        val on = p.key in ui.sel
                        Box(Modifier.aspectRatio(1f).clickable { toggleItem(ui, p) }) {
                            Thumb(p, Modifier.fillMaxSize())
                            if (on) Box(Modifier.fillMaxSize().background(Pink.copy(alpha = 0.22f)))
                            SelDot(on, Modifier.align(Alignment.TopEnd).padding(5.dp))
                        }
                    }
                }
            }
        }
    }
}
