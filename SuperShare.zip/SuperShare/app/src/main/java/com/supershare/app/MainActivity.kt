package com.supershare.app

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.Bundle
import android.os.Handler
import android.os.StatFs
import android.os.PowerManager
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.core.location.LocationManagerCompat
import com.supershare.app.core.Keys
import com.supershare.app.core.Progress
import com.supershare.app.core.Protocol
import com.supershare.app.core.Receiver
import com.supershare.app.core.ReceiverEvents
import com.supershare.app.core.Registry
import com.supershare.app.core.Sender
import java.io.File
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.ConcurrentHashMap

const val PORT = 8988
const val REG_PORT = 8989

class DeviceInfo(val ip: String, val name: String, val port: Int)
class DevState(val progress: Float, val mbps: Float, val status: String)
class BrowseEntry(val path: String, val name: String, val dir: Boolean, val size: Long, val modified: Long)

class Meter {
    private var t0 = 0L
    private var base = 0L
    private var last = 0L
    fun update(d: Long, t: Long): DevState? {
        val now = System.nanoTime()
        if (t0 == 0L) { t0 = now; base = d }
        if (d < t && now - last < 200_000_000L) return null
        last = now
        val sec = (now - t0) / 1e9
        val mbps = if (sec > 0.3) ((d - base) * 8 / 1e6 / sec).toFloat() else 0f
        return DevState(if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else 0f, mbps, "Sending…")
    }
}

class InFile(val id: String, val name: String, val size: Long)

class UiState {
    var screen by mutableStateOf("home")      // home, pick, send, group, receive, join, files
    var prev by mutableStateOf("home")
    var status by mutableStateOf("")
    var message by mutableStateOf("")
    var qr by mutableStateOf("")              // text of the QR code shown on this phone
    var modeFor by mutableStateOf("send")     // the One share / Group share chooser: send or receive
    var scanning by mutableStateOf(false)     // the QR scanner is open
    var scanTitle by mutableStateOf("")
    var scanHint by mutableStateOf("")
    var incoming by mutableStateOf<List<InFile>>(emptyList())   // files arriving on this phone
    var incDone by mutableStateOf<Set<String>>(emptySet())
    var files by mutableStateOf<List<Item>>(emptyList())
    var blocked by mutableStateOf<Set<String>>(emptySet())
    var current by mutableStateOf("")
    var active by mutableStateOf(false)
    var busy by mutableStateOf(false)
    var joined by mutableStateOf(false)
    var manage by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var mbps by mutableFloatStateOf(0f)
    var peak by mutableFloatStateOf(0f)
    var eta by mutableLongStateOf(-1L)
    var done by mutableLongStateOf(0L)
    var total by mutableLongStateOf(0L)
    var free by mutableLongStateOf(0L)
    var spaceAlert by mutableStateOf("")
    var library by mutableStateOf<List<RFile>>(emptyList())
    var partials by mutableStateOf<List<Partial>>(emptyList())
    var allFiles by mutableStateOf(false)
    var mediaOk by mutableStateOf(true)
    var browsePath by mutableStateOf("")
    var browseEntries by mutableStateOf<List<BrowseEntry>>(emptyList())
    // file picker
    var pickMode by mutableStateOf("single")  // single (scan the receiver) or group (show a QR)
    var pickTab by mutableIntStateOf(0)
    var pickSub by mutableIntStateOf(0)
    var pickView by mutableStateOf("home")    // home, docs, ebooks, archives, big, browse
    var pickQuery by mutableStateOf("")
    var searching by mutableStateOf(false)
    var loadingPick by mutableStateOf(false)
    var pickReturn by mutableStateOf(false)   // picker opened from the Send screen ("send more files")
    val sel = mutableStateMapOf<String, PickItem>()
    var videos by mutableStateOf<List<PickItem>>(emptyList())
    var images by mutableStateOf<List<PickItem>>(emptyList())
    var audios by mutableStateOf<List<PickItem>>(emptyList())
    var apps by mutableStateOf<List<PickItem>>(emptyList())
    var docs by mutableStateOf<List<PickItem>>(emptyList())
    var ebooks by mutableStateOf<List<PickItem>>(emptyList())
    var archives by mutableStateOf<List<PickItem>>(emptyList())
    var big by mutableStateOf<List<PickItem>>(emptyList())
    var storageUsed by mutableLongStateOf(0L)
    var storageTotal by mutableLongStateOf(0L)
    // sending
    var skipped by mutableStateOf<Set<String>>(emptySet())      // files the user cancelled
    val fileProg = mutableStateMapOf<String, Float>()
    var finished by mutableStateOf(false)
    var canResume by mutableStateOf(false)
    var wifiOn by mutableStateOf(true)
    var prompt by mutableStateOf("")          // "", "wifi" or "location": asks the user to switch it on
    var recent by mutableStateOf<List<RFile>>(emptyList())   // files received in this session only
    var needLocation by mutableStateOf(false)
    var locationOn by mutableStateOf(true)
    var devices by mutableStateOf<List<DeviceInfo>>(emptyList())
    var deselected by mutableStateOf<Set<String>>(emptySet())
    val devState = mutableStateMapOf<String, DevState>()
    private var t0 = 0L
    private var base = 0L
    private var lastUi = 0L

    fun newBatch() { t0 = 0L; base = 0L; progress = 0f; mbps = 0f; eta = -1L }
    fun reset() {
        newBatch(); peak = 0f; status = ""; current = ""; active = false; joined = false
        done = 0; total = 0; spaceAlert = ""; blocked = emptySet(); busy = false
        finished = false; canResume = false; skipped = emptySet(); fileProg.clear(); qr = ""
        incoming = emptyList(); incDone = emptySet(); scanning = false
    }
    fun update(d: Long, t: Long) {
        val now = System.nanoTime()
        if (t0 == 0L) { t0 = now; base = d }
        if (d < t && now - lastUi < 100_000_000L) return      // keep the screen smooth
        lastUi = now
        active = true; done = d; total = t
        progress = if (t > 0) (d.toFloat() / t).coerceIn(0f, 1f) else 0f
        val sec = (now - t0) / 1e9
        if (sec > 0.3) {
            val bps = (d - base) / sec
            mbps = (bps * 8 / 1e6).toFloat()
            if (mbps > peak) peak = mbps
            eta = if (bps > 1) ((t - d) / bps).toLong() else -1L
        }
    }
}

class MainActivity : ComponentActivity() {
    private val ui = UiState()
    private lateinit var storage: AndroidStorage
    private var wd: WifiDirect? = null
    private var receiver: Receiver? = null
    private var registry: Registry? = null
    private var heartbeat: Thread? = null
    private var picked: List<Item> = emptyList()
    private val sending = AtomicBoolean(false)
    private val cancel = AtomicBoolean(false)
    private val groupRunning = AtomicInteger(0)
    private var groupCode = ""
    private var lastHost: String? = null
    private var lastCode: String = ""
    private var sessionCode: String = ""      // code of the receiver we are sending to (kept for Resume)
    private val skipSet: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private var mediaFromButton = false
    private var scanCb: ((String) -> Unit)? = null
    private var sessionSsid = ""               // Wi-Fi name / password of the phone we join (only set for Android 7-9 hosts)
    private var sessionPass = ""
    private var sessionStart = 0L
    private var pendingAction: (() -> Unit)? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wakeLock: PowerManager.WakeLock? = null

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    private val mediaPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshStatus()
        if (!ui.mediaOk && mediaFromButton) openSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        mediaFromButton = false
        loadPickerData()
    }
    private val cameraPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) ui.scanning = true else { scanCb = null; ui.message = "Allow camera access to scan the QR code" }
    }
    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        storage = AndroidStorage(applicationContext)
        perms.launch(
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
            else if (Build.VERSION.SDK_INT >= 29) arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        )
        refresh()
        val actions = Actions(
            onReceive = { guard { startReceive() } },
            onSend = { openPicker("single", false) },
            onGroup = { openPicker("group", false) },                         // Group Share opens on the file picker (Send selected)
            onOneShare = { openPicker("group", false) },                    // Group Share > Sender
            onGroupShare = { stopAll(); ui.reset(); ui.screen = "join"; scanGroupQr() },   // Group Share > Receiver
            onCancelIncoming = { cancelIncoming(it) },
            onScanResult = { text -> ui.scanning = false; val cb = scanCb; scanCb = null; cb?.invoke(text) },
            onScanClose = { ui.scanning = false; scanCb = null },
            onScanGroup = { scanGroupQr() },
            onPickSend = { pickSend() },
            onPickClose = { closePicker() },
            onBrowseRoot = { openBrowser() },
            onBrowseOpen = { loadDir(it) },
            onBrowseUp = { browseUp() },
            onAllFilesAccess = { requestAllFiles() },
            onMediaAccess = { requestMedia(true) },
            onResume = { guard { beginSend(sessionCode, sessionSsid, sessionPass) } },
            onSendMore = { openPicker("single", true) },
            onConfirmGroup = { sendGroup() },
            onCancelFile = { cancelFile(it) },
            onToggleDevice = { ip -> ui.deselected = if (ip in ui.deselected) ui.deselected - ip else ui.deselected + ip },
            onStop = { cancel.set(true) },
            onBack = { back() },
            onFiles = { refresh(); ui.manage = false; ui.prev = ui.screen; ui.screen = "files" },
            onManage = { refresh(); ui.manage = true; ui.prev = ui.screen; ui.screen = "files" },
            onOpen = { openFile(it) },
            onDelete = { deleteFile(it) },
            onDiscard = { Library.discard(this, it); refresh() },
            onStorageSettings = { openStorageSettings() },
            onWifi = { openWifiPanel() },
            onLocation = { openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS) },
            onDismissPrompt = { pendingAction = null; ui.prompt = "" },
            onRefresh = { refresh(); checkPending() }
        )
        setContent { SuperTheme { AppScreen(ui, actions) } }
    }

    override fun onResume() {
        super.onResume()
        refresh()
        checkPending()
        if (ui.screen == "pick") loadPickerData()
    }

    // ---------------- Wi-Fi / Location must be on ----------------
    /** "" when everything needed is on, otherwise what to ask for. */
    private fun needed(): String = when {
        !ui.wifiOn -> "wifi"
        ui.needLocation && !ui.locationOn -> "location"
        else -> ""
    }

    /** Runs [action] now, or shows the "please turn on Wi-Fi" popup and runs it as soon as Wi-Fi is on. */
    private fun guard(action: () -> Unit) {
        refreshStatus()
        val need = needed()
        if (need.isEmpty()) { action(); return }
        pendingAction = action
        ui.prompt = need
    }

    private fun checkPending() {
        val p = pendingAction ?: return
        val need = needed()
        if (need.isEmpty()) { pendingAction = null; ui.prompt = ""; p() } else ui.prompt = need
    }

    // ---------------- status ----------------
    private fun refreshStatus() {
        ui.free = freeSpace(applicationContext)
        ui.allFiles = hasAllFiles()
        ui.mediaOk = mediaPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            ui.wifiOn = wm.isWifiEnabled
        } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT < 33) {
            ui.needLocation = true
            try { ui.locationOn = LocationManagerCompat.isLocationEnabled(getSystemService(Context.LOCATION_SERVICE) as LocationManager) }
            catch (e: Exception) { }
        } else ui.needLocation = false
    }

    private fun refresh() {
        refreshStatus()
        val s = ui.screen
        if (s == "receive" || s == "join" || s == "files") {
            ui.library = Library.list(applicationContext)
            ui.partials = Library.partials(applicationContext)
            ui.recent = ui.library.filter { it.added >= sessionStart }
        }
        val reg = registry
        if (reg != null) ui.devices = reg.devices().map { DeviceInfo(it.ip, it.name, it.port) }
    }

    private fun back() {
        if (ui.scanning) { ui.scanning = false; scanCb = null; return }
        if (ui.screen == "files") { ui.screen = ui.prev; return }
        if (ui.screen == "pick") { pickBack(); return }
        if (ui.screen == "group") { stopAll(); openPicker("group", false); return }   // back from the QR screen to the file picker
        stopAll(); ui.screen = "home"
    }

    /** Android does not let an app switch Wi-Fi / Bluetooth on by itself, so these open the system panel. */
    private fun openWifiPanel() {
        if (Build.VERSION.SDK_INT >= 29) {
            try { startActivity(Intent(Settings.Panel.ACTION_WIFI)); return } catch (e: Exception) { }
        }
        openSettings(Settings.ACTION_WIFI_SETTINGS)
    }

    private fun openSettings(action: String, uri: Uri? = null) {
        try { startActivity(Intent(action).apply { if (uri != null) setData(uri) }) } catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { } }
    }

    /** Keep Wi-Fi at full performance and the CPU/screen awake while transferring. */
    private fun boost() {
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wifiLock == null) wifiLock = wm.createWifiLock(if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF, "SuperShare").apply { acquire() }
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (wakeLock == null) wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SuperShare:xfer").apply { acquire(60 * 60 * 1000L) }
        } catch (e: Exception) { }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun deviceName(): String {
        val n = try { Settings.Global.getString(contentResolver, "device_name") } catch (e: Exception) { null }
        return n?.takeIf { it.isNotBlank() } ?: Build.MODEL
    }

    // ---------------- the file picker ----------------
    private fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAllFiles() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) { openSettings(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION) }
        } else perms.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE))
    }

    private fun mediaPermissions(): List<String> =
        if (Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO)
        else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun requestMedia(fromButton: Boolean) {
        val missing = mediaPermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) { loadPickerData(); return }
        mediaFromButton = fromButton
        mediaPerms.launch(missing.toTypedArray())
    }

    @Suppress("DEPRECATION")
    private fun storageRoot(): String = Environment.getExternalStorageDirectory().absolutePath

    /** Opens the "Select Files To Share" screen. mode: "single" (then scan the receiver's QR) or "group" (then show a QR). */
    private fun openPicker(mode: String, fromSend: Boolean) {
        if (!fromSend) { stopAll(); ui.reset(); picked = emptyList(); ui.files = emptyList() }
        ui.pickMode = mode
        ui.pickReturn = fromSend
        ui.sel.clear()
        ui.pickTab = 0; ui.pickSub = 0; ui.pickView = "home"; ui.pickQuery = ""; ui.searching = false
        ui.screen = "pick"
        refreshStatus()
        requestMedia(false)          // loads the lists at once, or after the permission answer
    }

    private fun loadPickerData() {
        ui.loadingPick = true
        val app = applicationContext
        Thread {
            try {
                ui.videos = MediaLoader.videos(app)
                ui.images = MediaLoader.images(app)
                ui.audios = MediaLoader.audio(app)
                ui.apps = MediaLoader.apps(app)
                val f = MediaLoader.files(app)
                ui.docs = f.docs; ui.ebooks = f.ebooks; ui.archives = f.archives; ui.big = f.big
                try {
                    val st = StatFs(storageRoot())
                    ui.storageTotal = st.totalBytes
                    ui.storageUsed = st.totalBytes - st.availableBytes
                } catch (e: Exception) { }
            } catch (e: Exception) { }
            ui.loadingPick = false
        }.start()
    }

    private fun pickBack() {
        if (ui.searching) { ui.searching = false; ui.pickQuery = ""; return }
        if (ui.pickTab == 0 && ui.pickView == "browse") { browseUp(); return }
        if (ui.pickTab == 0 && ui.pickView != "home") { ui.pickView = "home"; return }
        closePicker()
    }

    private fun closePicker() {
        if (ui.pickReturn) { ui.screen = "send"; return }
        stopAll()
        // Send (one phone) goes back home; Group Share > Send goes back to the Send | Receive screen of Group Share.
        ui.screen = "home"
    }

    private fun openBrowser() {
        if (!hasAllFiles()) {
            ui.message = "Turn on \"Allow access to all files\" for Super Share, then come back and open Internal Storage again."
            requestAllFiles()
            return
        }
        ui.pickView = "browse"
        loadDir(storageRoot())
    }

    private fun loadDir(path: String) {
        val list = try { File(path).listFiles() } catch (e: SecurityException) { null }
        if (list == null) { ui.message = "Cannot open this folder"; return }
        ui.browsePath = path
        ui.pickQuery = ""
        ui.browseEntries = list.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
            .map { BrowseEntry(it.absolutePath, it.name, it.isDirectory, if (it.isDirectory) 0L else it.length(), it.lastModified()) }
    }

    private fun browseUp() {
        val parent = File(ui.browsePath).parentFile
        if (ui.browsePath != storageRoot() && parent != null) loadDir(parent.absolutePath) else ui.pickView = "home"
    }

    /** SEND pressed in the picker: the ticked files become the queue, then scan (one phone) or show a QR (group). */
    private fun pickSend() {
        val items = ui.sel.values.map { Item(it.uri, it.name, it.size, it.id) }.distinctBy { it.id }
        if (items.isEmpty()) return
        picked = items
        ui.files = items
        skipSet.clear(); ui.skipped = emptySet(); ui.fileProg.clear(); ui.blocked = emptySet()
        if (ui.pickMode == "group") { guard { startGroup() }; return }
        val host = lastHost
        if (ui.pickReturn && host != null && lastCode.isNotEmpty()) { beginSend(lastCode, sessionSsid, sessionPass); return }   // still connected: no new scan
        scanReceiverQr()          // the camera opens at once; Wi-Fi / location are checked after the QR code is read
    }

    // ---------------- QR scanning ----------------
    private fun scanQr(title: String, hint: String, onText: (String) -> Unit) {
        scanCb = onText
        ui.scanTitle = title
        ui.scanHint = hint
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) ui.scanning = true
        else cameraPerm.launch(Manifest.permission.CAMERA)
    }

    /** One phone: the sender scans the QR code that the receiver shows. */
    private fun scanReceiverQr() {
        scanQr("Scan the receiver's QR code", "Point the camera at the QR code on the receiving phone") { raw ->
            val q = Keys.fromQr(raw)
            when {
                q == null -> ui.message = "That is not a Super Share QR code"
                q[0][0] != Keys.QR_RECEIVER -> ui.message = "That QR code belongs to a group. On the receiving phone choose Receive, then One Share."
                else -> guard { beginSend(q[1], q[2], q[3]) }
            }
        }
    }

    /** Group: a receiver scans the QR code that the group sender shows. */
    private fun scanGroupQr() {
        scanQr("Scan the group QR code", "Point the camera at the QR code on the sender's phone") { raw ->
            val q = Keys.fromQr(raw)
            when {
                q == null -> ui.message = "That is not a Super Share QR code"
                q[0][0] != Keys.QR_GROUP -> ui.message = "That QR code is for one phone. The sender must choose Group Share."
                else -> guard { joinGroup(q[1], q[2], q[3]) }
            }
        }
    }

    /** This phone does not want a file that is arriving: the sender stops it, the partial copy is deleted. */
    private fun cancelIncoming(id: String) {
        ui.skipped = ui.skipped + id
        val r = receiver
        if (r != null) Thread { r.reject(id) }.start()
    }

    private fun cancelFile(id: String) {
        if (!ui.busy) {         // nothing is being sent right now: just take it out of the queue
            picked = picked.filter { it.id != id }
            ui.files = picked
            return
        }
        skipSet.add(id)         // the sender stops this file at once and the receiver deletes its partial copy
        ui.skipped = ui.skipped + id
    }

    // ---------------- receiving (show my QR code) ----------------
    private fun makeEvents() = object : ReceiverEvents {
        override fun onBatch(done: Long, total: Long, blocked: Int, maxNeedMore: Long, firstBlockedName: String) {
            ui.newBatch()
            ui.spaceAlert = if (blocked > 0)
                "Not enough storage for \"$firstBlockedName\"" +
                    (if (blocked > 1) " and ${blocked - 1} more" else "") +
                    ". Free up ${fmtSize(maxNeedMore)} to continue."
            else ""
            refresh()
        }
        override fun onProgress(done: Long, total: Long) { ui.update(done, total) }
        override fun onFileStart(name: String) { ui.current = name }
        override fun onFileDone(name: String) { ui.status = "Received: $name"; refresh() }
        override fun onIncoming(id: String, name: String, size: Long) {
            ui.incoming = ui.incoming.filter { it.id != id } + InFile(id, name, size)
        }
        override fun onFileFinished(id: String) { ui.incDone = ui.incDone + id }
        override fun onFileCancelled(name: String) { ui.status = "Sender cancelled: $name"; refresh() }
        override fun onAuthFailed(totalFailures: Int) { ui.status = "A device tried a wrong code ($totalFailures)" }
    }

    private fun startReceive() {
        stopAll(); ui.reset(); ui.screen = "receive"; boost()
        sessionStart = System.currentTimeMillis() / 1000 - 1; ui.recent = emptyList()
        val code = Keys.newCode()
        if (Build.VERSION.SDK_INT >= 29) ui.qr = Keys.toQr(Keys.QR_RECEIVER, code)    // older phones: after the group exists
        ui.status = "Preparing a secure link…"
        refresh()
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    if (ui.screen != "receive" && ui.screen != "files") return@runOnUiThread
                    try {
                        val rx = Receiver(code, storage, makeEvents())
                        rx.start(PORT, null)
                        receiver = rx
                        wd = WifiDirect(this, {}, { ui.status = it }) { ssid, pass -> ui.qr = Keys.toQr(Keys.QR_RECEIVER, code, ssid, pass) }
                            .also { it.host(k) }
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    // ---------------- receiving (join a group) ----------------
    private fun joinGroup(code: String, ssid: String, pass: String) {
        if (!Keys.isValid(code)) { ui.status = "Invalid QR code"; return }
        stopAll(); ui.reset(); ui.screen = "join"; boost()
        sessionStart = System.currentTimeMillis() / 1000 - 1; ui.recent = emptyList()
        ui.status = "Connecting to the sender…"
        Thread {
            try {
                val k = Keys.derive(code)
                val wifiName = ssid.ifEmpty { k.wifiName }
                val wifiPass = if (ssid.isEmpty()) k.wifiPass else pass
                runOnUiThread {
                    try {
                        val rx = Receiver(code, storage, makeEvents())
                        rx.start(PORT, null)
                        receiver = rx
                        val w = WifiDirect(this, { host -> onGroupJoined(host) }, { ui.status = it })
                        wd = w
                        Handler(mainLooper).postDelayed({ w.join(wifiName, wifiPass) }, 500)
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    private fun onGroupJoined(host: String?) {
        if (host == null || ui.joined) return
        ui.joined = true
        ui.status = "Connected. Waiting for the sender to start…"
        heartbeat?.interrupt()
        val name = deviceName()
        val t = Thread {
            while (!Thread.currentThread().isInterrupted) {
                try { Registry.register(host, REG_PORT, name, PORT) } catch (e: IOException) { }
                try { Thread.sleep(4000) } catch (e: InterruptedException) { break }
            }
        }
        t.isDaemon = true
        t.start()
        heartbeat = t
    }

    // ---------------- sending to one phone ----------------
    /** Called after the receiver's QR code was scanned (or by Resume / Send more). */
    private fun beginSend(code: String, ssid: String = sessionSsid, pass: String = sessionPass) {
        if (picked.isEmpty()) { ui.status = "Choose the files to send first"; return }
        if (!Keys.isValid(code)) { ui.status = "Scan the receiver's QR code again"; return }
        sessionCode = code; sessionSsid = ssid; sessionPass = pass
        ui.screen = "send"; ui.finished = false; ui.canResume = false; ui.message = ""
        ui.newBatch(); ui.active = false
        boost(); cancel.set(false)
        val host = lastHost
        if (host != null && lastCode == code) { doSend(host, code); return }
        ui.status = "Connecting securely…"
        wd?.stop(); wd = null; sending.set(false)
        Thread {
            try {
                val k = Keys.derive(code)
                val wifiName = ssid.ifEmpty { k.wifiName }
                val wifiPass = if (ssid.isEmpty()) k.wifiPass else pass
                runOnUiThread {
                    val w = WifiDirect(this,
                        { host -> if (host != null) doSend(host, code) },
                        { ui.status = it })
                    wd = w
                    Handler(mainLooper).postDelayed({ w.join(wifiName, wifiPass) }, 700)
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    private fun doSend(host: String, code: String) {
        if (!sending.compareAndSet(false, true)) return
        lastHost = host
        lastCode = code
        cancel.set(false)
        val items = picked
        ui.busy = true; ui.canResume = false; ui.finished = false
        Thread {
            val sources = items.map { AndroidSource(applicationContext, it) }
            var failures = 0
            var waited = 0L
            var failure: Exception? = null
            val fileProgress = Sender.FileProgress { id, sent, size ->
                if (sent < 0) ui.skipped = ui.skipped + id            // the receiver does not want this file
                else ui.fileProg[id] = if (size > 0) (sent.toFloat() / size).coerceIn(0f, 1f) else 1f
            }
            try {
                while (!cancel.get()) {
                    try {
                        ui.status = "Sending…"
                        val r = Sender.send(host, PORT, code, sources, Progress { d, t -> ui.update(d, t) }, cancel,
                            Protocol.BIG_STREAMS, skipSet, fileProgress)
                        failures = 0
                        if (r.complete) {
                            ui.blocked = emptySet()
                            ui.finished = true
                            val n = items.count { it.id !in skipSet }
                            ui.status = "Done ✓ $n file(s)" +
                                (if (r.haveCount > 0) " (${r.haveCount} already on the receiver)" else "")
                            break
                        }
                        ui.blocked = r.blockedIds.toSet()
                        ui.status = "Receiver has insufficient storage. Waiting for ${fmtSize(r.needMore)} more space — " +
                            "it can free space inside Super Share."
                        Thread.sleep(5000)
                        waited += 5000
                        if (waited > 15 * 60 * 1000L) { ui.status = "Stopped waiting for space. Tap Resume to try again."; ui.canResume = true; break }
                    } catch (e: IOException) {
                        if (cancel.get()) break
                        failures++
                        if (failures >= 4) throw e
                        ui.status = "Connection dropped, resuming… ($failures/4)"
                        Thread.sleep(2000)
                    }
                }
                if (cancel.get()) { ui.status = "Stopped. Tap Resume to continue where it stopped."; ui.canResume = true }
            } catch (e: Exception) {
                failure = e
            }
            val f = failure
            if (f != null) {
                lastHost = null     // the next tap re-joins the Wi-Fi link, then resumes from where it stopped
                ui.status = "Interrupted: ${f.message}. Tap Resume to continue where it stopped."
                ui.canResume = true
            }
            ui.busy = false
            sending.set(false)
        }.start()
    }

    // ---------------- group share (sender hosts, several phones join) ----------------
    private fun startGroup() {
        stopAll(); ui.reset(); ui.screen = "group"; boost()
        ui.deselected = emptySet(); ui.devState.clear(); ui.devices = emptyList()
        ui.files = picked
        val code = Keys.newCode()
        groupCode = code
        if (Build.VERSION.SDK_INT >= 29) ui.qr = Keys.toQr(Keys.QR_GROUP, code)       // older phones: after the group exists
        ui.status = "Preparing the group…"
        Thread {
            try {
                val k = Keys.derive(code)
                runOnUiThread {
                    if (ui.screen != "group") return@runOnUiThread
                    try {
                        val reg = Registry()
                        reg.start(REG_PORT, null)
                        registry = reg
                        wd = WifiDirect(this, {}, { ui.status = it }) { ssid, pass -> ui.qr = Keys.toQr(Keys.QR_GROUP, code, ssid, pass) }
                            .also { it.host(k) }
                    } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
                }
            } catch (e: Exception) { ui.status = "Could not start: ${e.message}" }
        }.start()
    }

    /** "SEND" (group): start sending to every receiver that scanned the QR code (and was not unticked). */
    private fun sendGroup() {
        if (picked.isEmpty()) { ui.status = "Choose the files to send first"; return }
        val targets = ui.devices.filter { it.ip !in ui.deselected }
        if (targets.isEmpty()) { ui.status = "No phone has scanned the QR code yet."; return }
        if (groupRunning.get() > 0) return
        cancel.set(false)
        ui.busy = true
        ui.status = "Sending to ${targets.size} phone(s)…"
        val items = picked
        val code = groupCode
        ui.finished = false
        val streams = if (targets.size > 2) 3 else 4
        groupRunning.set(targets.size)
        for (dev in targets) Thread { sendToDevice(dev, items, code, streams) }.start()
    }

    private fun sendToDevice(dev: DeviceInfo, items: List<Item>, code: String, streams: Int) {
        val sources = items.map { AndroidSource(applicationContext, it) }
        val meter = Meter()
        var last = 0f
        var failures = 0
        var waited = 0L
        ui.devState[dev.ip] = DevState(0f, 0f, "Starting…")
        try {
            while (!cancel.get()) {
                try {
                    val r = Sender.send(dev.ip, dev.port, code, sources, Progress { d, t ->
                        val s = meter.update(d, t)
                        if (s != null) { last = s.progress; ui.devState[dev.ip] = s }
                    }, cancel, streams, skipSet, null)
                    failures = 0
                    if (r.complete) { ui.devState[dev.ip] = DevState(1f, 0f, "Done ✓"); break }
                    ui.devState[dev.ip] = DevState(last, 0f, "Waiting: needs ${fmtSize(r.needMore)} more space")
                    Thread.sleep(5000)
                    waited += 5000
                    if (waited > 15 * 60 * 1000L) { ui.devState[dev.ip] = DevState(last, 0f, "Stopped waiting for space"); break }
                } catch (e: IOException) {
                    if (cancel.get()) break
                    failures++
                    if (failures >= 4) throw e
                    ui.devState[dev.ip] = DevState(last, 0f, "Connection dropped, resuming… ($failures/4)")
                    Thread.sleep(2000)
                }
            }
            if (cancel.get()) ui.devState[dev.ip] = DevState(last, 0f, "Stopped")
        } catch (e: Exception) {
            ui.devState[dev.ip] = DevState(last, 0f, "Failed: ${e.message}")
        }
        if (groupRunning.decrementAndGet() <= 0) {
            val ok = ui.devState.values.count { it.status.startsWith("Done") }
            ui.status = "Finished: $ok of ${ui.devState.size} phone(s) received everything"
            ui.busy = false
            ui.finished = true
        }
    }

    // ---------------- files ----------------
    private fun openFile(f: RFile) {
        try {
            val u = if (f.uri.scheme == "file") FileProvider.getUriForFile(this, "$packageName.files", java.io.File(f.uri.path ?: ""))
                    else f.uri
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, f.mime)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: ActivityNotFoundException) {
            ui.message = "No app on this phone can open ${f.name}"
        }
    }

    private fun deleteFile(f: RFile) {
        try {
            if (f.uri.scheme == "file") java.io.File(f.uri.path ?: "").delete() else contentResolver.delete(f.uri, null, null)
            refresh()
        } catch (e: SecurityException) {
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val pi = MediaStore.createDeleteRequest(contentResolver, listOf(f.uri))
                    deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                    deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                } else ui.message = "Could not delete ${f.name}"
            } catch (e2: Exception) { ui.message = "Could not delete ${f.name}" }
        }
    }

    private fun openStorageSettings() {
        try { startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)) }
        catch (e: Exception) { openSettings(Settings.ACTION_SETTINGS) }
    }

    private fun stopAll() {
        cancel.set(true)
        heartbeat?.interrupt(); heartbeat = null
        val r = receiver; receiver = null
        if (r != null) Thread { r.stop() }.start()       // stop() waits for saves, keep it off the UI thread
        val reg = registry; registry = null
        if (reg != null) Thread { reg.stop() }.start()
        wd?.stop(); wd = null
        lastHost = null
        ui.devices = emptyList(); ui.devState.clear()
        try { wifiLock?.release() } catch (e: Exception) { }
        wifiLock = null
        try { wakeLock?.release() } catch (e: Exception) { }
        wakeLock = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroy() { stopAll(); super.onDestroy() }
}
