package com.supershare.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.sp
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

class Actions(
    val onReceive: () -> Unit,
    val onSend: () -> Unit,
    val onGroup: () -> Unit,
    val onOneShare: () -> Unit,
    val onGroupShare: () -> Unit,
    val onCancelIncoming: (String) -> Unit,
    val onScanResult: (String) -> Unit,
    val onScanClose: () -> Unit,
    val onScanGroup: () -> Unit,
    val onPickSend: () -> Unit,
    val onPickClose: () -> Unit,
    val onBrowseRoot: () -> Unit,
    val onBrowseOpen: (String) -> Unit,
    val onBrowseUp: () -> Unit,
    val onAllFilesAccess: () -> Unit,
    val onMediaAccess: () -> Unit,
    val onResume: () -> Unit,
    val onSendMore: () -> Unit,
    val onConfirmGroup: () -> Unit,
    val onCancelFile: (String) -> Unit,
    val onToggleDevice: (String) -> Unit,
    val onStop: () -> Unit,
    val onBack: () -> Unit,
    val onFiles: () -> Unit,
    val onManage: () -> Unit,
    val onOpen: (RFile) -> Unit,
    val onDelete: (RFile) -> Unit,
    val onDiscard: (Partial) -> Unit,
    val onStorageSettings: () -> Unit,
    val onWifi: () -> Unit,
    val onLocation: () -> Unit,
    val onDismissPrompt: () -> Unit,
    val onRefresh: () -> Unit
)

@Composable
fun AppScreen(ui: UiState, act: Actions) {
    BackHandler(enabled = ui.screen != "home") { act.onBack() }
    LaunchedEffect(Unit) {
        while (true) { act.onRefresh(); delay(2000) }
    }
    LaunchedEffect(ui.message) {
        if (ui.message.isNotEmpty()) { delay(4000); ui.message = "" }
    }
    var confirm by remember { mutableStateOf<RFile?>(null) }
    val pending = confirm
    if (pending != null) {
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("Delete file?") },
            text = { Text("\"${pending.name}\" (${fmtSize(pending.size)}) will be deleted from this phone.") },
            confirmButton = { TextButton(onClick = { act.onDelete(pending); confirm = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel") } }
        )
    }
    if (ui.prompt.isNotEmpty()) {
        val wifi = ui.prompt == "wifi"
        AlertDialog(
            onDismissRequest = { act.onDismissPrompt() },
            title = { Text(if (wifi) "Turn on Wi-Fi" else "Turn on Location") },
            text = {
                Text(if (wifi) "Please turn on Wi-Fi to send or receive files."
                else "Please turn on Location to send or receive files on this Android version.")
            },
            confirmButton = {
                TextButton(onClick = { if (wifi) act.onWifi() else act.onLocation() }) {
                    Text(if (wifi) "Turn on Wi-Fi" else "Turn on Location")
                }
            },
            dismissButton = { TextButton(onClick = { act.onDismissPrompt() }) { Text("Cancel") } }
        )
    }

    if (ui.scanning) {
        ScannerScreen(ui.scanTitle, ui.scanHint, act.onScanResult, act.onScanClose)
        return
    }
    if (ui.screen == "pick") {
        Box(Modifier.fillMaxSize().background(AppBg)) { PickerScreen(ui, act) }
        return
    }
    if (ui.screen == "home") {
        HomeFull(act)
        return
    }
    Screen(header = {
        when (ui.screen) {
            "mode" -> Header("Group Share", act.onBack)
            "send" -> Header("Send", act.onBack)
            "group" -> Header("Group Share", act.onBack)
            "receive", "join" -> Header("Receive", act.onBack)
            "files" -> Header(if (ui.manage) "Free up space" else "Received files", act.onBack)
            else -> Header("Super Share", act.onBack)
        }
    }) {
        when (ui.screen) {
            "mode" -> ModeScreen(ui, act)
            "receive" -> ReceiveScreen(ui, act) { confirm = it }
            "join" -> JoinScreen(ui, act) { confirm = it }
            "group" -> GroupScreen(ui, act)
            "files" -> FilesScreen(ui, act) { confirm = it }
            else -> SendScreen(ui, act)
        }
    }
}

// ---------------- shared pieces ----------------

@Composable
private fun StatusText(ui: UiState) {
    if (ui.status.isEmpty()) return
    val done = ui.status.startsWith("Done")
    val bad = ui.status.startsWith("Interrupted") || ui.status.startsWith("Failed") || ui.status.startsWith("Could not")
    Text(ui.status, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center,
        color = if (done) MaterialTheme.colorScheme.tertiary else if (bad) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp))
}

@Composable
private fun MessageText(ui: UiState) {
    if (ui.message.isEmpty()) return
    Text(ui.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error,
        modifier = Modifier.padding(vertical = 4.dp))
}

/** A QR code in a card, with a line of help under it. */
@Composable
private fun QrCard(label: String, qr: String, hint: String, dim: androidx.compose.ui.unit.Dp) {
    SurfaceCard(horizontalAlignment = Alignment.CenterHorizontally) {
        SectionLabel(label)
        Spacer(Modifier.height(10.dp))
        if (qr.isNotEmpty()) QrImage(qr, dim)
        else Box(Modifier.size(dim), contentAlignment = Alignment.Center) { CircularProgressIndicator(strokeWidth = 3.dp) }
        Spacer(Modifier.height(10.dp))
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

@Composable
private fun CancelButton(onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.errorContainer).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { AppIcon("close", MaterialTheme.colorScheme.error, 18.dp) }
}

/** One file of the queue. The red X cancels just this file (also while it is being sent). */
@Composable
private fun QueueRow(ui: UiState, f: Item, perFile: Boolean, onCancel: (String) -> Unit) {
    val cancelled = f.id in ui.skipped
    val prog = if (perFile) ui.fileProg[f.id] else null
    val finished = prog != null && prog >= 1f
    val sub = when {
        cancelled -> "Cancelled"
        f.id in ui.blocked -> "Waiting: receiver needs more storage"
        finished -> "Sent ✓  ·  ${fmtSize(f.size)}"
        prog != null && prog > 0f && ui.busy -> "Sending ${(prog * 100).toInt()}%  ·  ${fmtSize(f.size)}"
        else -> fmtSize(f.size)
    }
    Column {
        FileRow(f.name, sub, Modifier.alpha(if (cancelled) 0.45f else 1f)) {
            if (!cancelled && !finished) CancelButton { onCancel(f.id) }
        }
        if (prog != null && prog > 0f && prog < 1f && !cancelled) {
            LinearProgressIndicator(progress = { prog }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(4.dp),
                trackColor = MaterialTheme.colorScheme.surfaceContainerHighest)
            Spacer(Modifier.height(6.dp))
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

// ---------------- home ----------------

/** Home: the top half is logo, name and tagline; the bottom half is Send + Receive (big squares) and Received files (wide). */
@Composable
private fun HomeFull(act: Actions) {
    Box(Modifier.fillMaxSize().background(AppBg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp)) {
            Column(Modifier.weight(0.8f).fillMaxWidth(), verticalArrangement = Arrangement.Center) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { BigLogo(170.dp) }
                Spacer(Modifier.height(8.dp))
                Text("SUPER SHARE", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = Color.White,
                    fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(10.dp))
                Text("TRANSFER DATA MORE SECURE AND HIGH SPEED WITH YOUR FAMILY AND FRIENDS", Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Start, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp, lineHeight = 19.sp)
            }
            Column(Modifier.weight(1.2f).fillMaxWidth(), verticalArrangement = Arrangement.SpaceBetween) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SquareTile("SEND", "up", SendBrush, Modifier.weight(1f), onClick = act.onSend)
                        SquareTile("RECEIVE", "down", ReceiveBrush, Modifier.weight(1f), onClick = act.onReceive)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        SquareTile("GROUP SHARE", "group", GroupBrush, Modifier.weight(1f), onClick = act.onGroup)
                        SquareTile("RECEIVED FILES", "folder", FilesBrush, Modifier.weight(1f), onClick = act.onFiles)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    Image(painter = painterResource(R.drawable.logo_ring), contentDescription = null, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("© 2026 Super Share · Shashikumar H G", color = MaterialTheme.colorScheme.outline,
                        fontSize = 11.sp, letterSpacing = 0.2.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

/** Send / Receive: One share | Group share in one pill, side by side. Tapping either one continues. */
@Composable
private fun ColumnScope.ModeScreen(ui: UiState, act: Actions) {
    Spacer(Modifier.height(24.dp))
    PillOptions(listOf("Send", "Receive"), 0) { if (it == 0) act.onOneShare() else act.onGroupShare() }
    Spacer(Modifier.height(24.dp))
    SurfaceCard {
        Text("Send", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Cyan)
        Text("Choose files (like in Send) and tap Send to show a QR code. Many phones scan it, their names appear, then you tap Confirm to start.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Text("Receive", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = Cyan)
        Text("Scan the sender's QR code to join the group. All phones receive at the same time.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    Spacer(Modifier.weight(1f))
}

// ---------------- receive ----------------

@Composable
private fun ColumnScope.ReceiveBody(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    if (ui.active) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Gauge(ui, 170.dp) }
        Spacer(Modifier.height(12.dp))
        Stats(ui)
        if (ui.current.isNotEmpty()) {
            Text("Receiving ${ui.current}", style = MaterialTheme.typography.bodyMedium, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        }
    }
    if (ui.spaceAlert.isNotEmpty()) {
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.onErrorContainer)) {
            Column(Modifier.padding(16.dp)) {
                Text("Insufficient storage", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(ui.spaceAlert, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton("Free up space") { act.onManage() }
                    SmallButton("Phone storage") { act.onStorageSettings() }
                }
            }
        }
    }
    StatusText(ui)
    MessageText(ui)
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        if (ui.incoming.isNotEmpty()) {
            item { SectionLabel("Incoming files", Modifier.padding(top = 8.dp, bottom = 4.dp)) }
            items(ui.incoming, key = { "in:" + it.id }) { f -> IncomingRow(ui, f, act.onCancelIncoming) }
        }
        if (ui.recent.isNotEmpty()) item { SectionLabel("Received", Modifier.padding(top = 10.dp, bottom = 4.dp)) }
        items(ui.recent) { f -> ReceivedRow(f, act, askDelete, false) }
    }
}

@Composable
private fun ColumnScope.ReceiveScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    Spacer(Modifier.height(16.dp))
    if (!ui.active) {
        QrCard("Your QR code", ui.qr, "Ask the sender to choose One Share, pick the files and scan this QR code", 230.dp)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            Spacer(Modifier.padding(horizontal = 6.dp))
            Text("Waiting for the sender", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    ReceiveBody(ui, act, askDelete)
}

@Composable
private fun ColumnScope.JoinScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    Spacer(Modifier.height(16.dp))
    if (!ui.joined) {
        SurfaceCard(horizontalAlignment = Alignment.CenterHorizontally) {
            AppIcon("qr", MaterialTheme.colorScheme.primary, 64.dp)
            Spacer(Modifier.height(10.dp))
            Text("Join a group", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("The sender opens Send, Group Share, chooses the files and shows a QR code. Scan it to join.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(14.dp))
        PrimaryButton("Scan QR code") { act.onScanGroup() }
        StatusText(ui)
        MessageText(ui)
    } else {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon("check", MaterialTheme.colorScheme.tertiary, 20.dp)
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text("Joined the group", color = MaterialTheme.colorScheme.tertiary, style = MaterialTheme.typography.titleSmall)
        }
        ReceiveBody(ui, act, askDelete)
    }
}

@Composable
private fun ReceivedRow(f: RFile, act: Actions, askDelete: (RFile) -> Unit, manage: Boolean) {
    Column {
        FileRow(f.name, fmtSize(f.size)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallButton("Open") { act.onOpen(f) }
                if (manage) SmallButton("Delete", danger = true) { askDelete(f) }
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

// ---------------- my files / free up space ----------------

@Composable
private fun ColumnScope.FilesScreen(ui: UiState, act: Actions, askDelete: (RFile) -> Unit) {
    Spacer(Modifier.height(16.dp))
    val used = ui.library.sumOf { it.size }
    SurfaceCard {
        Text("Super Share files: ${fmtSize(used)}", style = MaterialTheme.typography.titleSmall)
        Text("Free space on this phone: ${fmtSize(ui.free)}", style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (ui.manage) {
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = act.onStorageSettings, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface)) {
            Text("Open phone storage settings")
        }
    }
    MessageText(ui)
    Spacer(Modifier.height(8.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        if (ui.manage && ui.partials.isNotEmpty()) {
            item { SectionLabel("Unfinished transfers", Modifier.padding(vertical = 8.dp)) }
            items(ui.partials) { p ->
                Column {
                    FileRow(p.name, "${fmtSize(p.done)} of ${fmtSize(p.size)} received") {
                        SmallButton("Discard", danger = true) { act.onDiscard(p) }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
        item { SectionLabel("Received files", Modifier.padding(vertical = 8.dp)) }
        if (ui.library.isEmpty()) {
            item { Text("No received files yet.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        items(ui.library) { f -> ReceivedRow(f, act, askDelete, ui.manage) }
    }
}

// ---------------- send to one phone (after the QR code was scanned) ----------------

@Composable
private fun ColumnScope.SendScreen(ui: UiState, act: Actions) {
    Spacer(Modifier.height(12.dp))
    if (ui.active) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Gauge(ui, 140.dp) }
        Spacer(Modifier.height(8.dp))
        Stats(ui)
        Spacer(Modifier.height(8.dp))
    }
    val left = ui.files.filter { it.id !in ui.skipped }
    SectionLabel("Files (${left.size}) · ${fmtSize(left.sumOf { it.size })}")
    MessageText(ui)
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.files, key = { it.id }) { f -> QueueRow(ui, f, true, act.onCancelFile) }
    }
    StatusText(ui)
    Spacer(Modifier.height(4.dp))
    when {
        ui.busy -> DangerButton("Stop") { act.onStop() }
        ui.canResume -> PrimaryButton("Resume") { act.onResume() }
        ui.finished -> PrimaryButton("Send more files") { act.onSendMore() }
        else -> DangerButton("Stop") { act.onStop() }
    }
    Spacer(Modifier.height(8.dp))
}

// ---------------- group share (sender) ----------------

/** A file that is arriving on this phone. The red X refuses it (the sender stops sending it). */
@Composable
private fun IncomingRow(ui: UiState, f: InFile, onCancel: (String) -> Unit) {
    val cancelled = f.id in ui.skipped
    val done = f.id in ui.incDone
    Column {
        FileRow(f.name, when { cancelled -> "Cancelled"; done -> "Received ✓  ·  ${fmtSize(f.size)}"; else -> fmtSize(f.size) },
            Modifier.alpha(if (cancelled) 0.45f else 1f)) {
            if (!cancelled && !done) CancelButton { onCancel(f.id) }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
    }
}

/** A receiver in the group: round avatar with its Wi-Fi / phone name. Tap to leave it out. */
@Composable
private fun ReceiverChip(d: DeviceInfo, on: Boolean, st: DevState?, onToggle: () -> Unit) {
    val palette = listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6), Color(0xFF10B981), Color(0xFFF59E0B), Color(0xFFEC4899), Color(0xFF06B6D4))
    val c = palette[(d.name.hashCode() and 0x7fffffff) % palette.size]
    Column(Modifier.width(88.dp).clickable(onClick = onToggle).alpha(if (on) 1f else 0.4f), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(contentAlignment = Alignment.Center) {
            if (st != null) CircularProgressIndicator(progress = { st.progress }, modifier = Modifier.size(70.dp), strokeWidth = 4.dp, color = Cyan,
                trackColor = Color.White.copy(alpha = 0.15f))
            Box(Modifier.size(60.dp).clip(CircleShape).background(Brush.linearGradient(listOf(c, c.copy(alpha = 0.55f)))), contentAlignment = Alignment.Center) {
                Text(d.name.trim().take(1).uppercase().ifEmpty { "?" }, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(d.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 12.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
        Text(when {
            st == null -> if (on) "Ready" else "Skipped"
            st.progress >= 1f -> "Done ✓"
            else -> "${(st.progress * 100).toInt()}%"
        }, fontSize = 10.sp, color = MaterialTheme.colorScheme.tertiary)
    }
}

@Composable
private fun ColumnScope.GroupScreen(ui: UiState, act: Actions) {
    Spacer(Modifier.height(10.dp))
    if (!ui.busy && !ui.finished) {
        QrCard("Scan to join", ui.qr, "Receivers: open Super Share, tap Group Share, then Receive, and scan this QR code", 190.dp)
        Spacer(Modifier.height(10.dp))
    }
    SectionLabel(if (ui.devices.isEmpty()) "Waiting for receivers to scan…" else "Receivers (${ui.devices.size})")
    Spacer(Modifier.height(8.dp))
    if (ui.devices.isNotEmpty()) {
        LazyRow(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ui.devices, key = { it.ip }) { d ->
                ReceiverChip(d, d.ip !in ui.deselected, ui.devState[d.ip]) { act.onToggleDevice(d.ip) }
            }
        }
    }
    val left = ui.files.filter { it.id !in ui.skipped }
    SectionLabel("Files (${left.size}) · ${fmtSize(left.sumOf { it.size })}", Modifier.padding(top = 12.dp, bottom = 2.dp))
    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
        items(ui.files, key = { it.id }) { f -> QueueRow(ui, f, false, act.onCancelFile) }
    }
    MessageText(ui)
    StatusText(ui)
    Spacer(Modifier.height(4.dp))
    val n = ui.devices.count { it.ip !in ui.deselected }
    val any = ui.files.any { it.id !in ui.skipped }
    when {
        ui.busy -> DangerButton("Stop") { act.onStop() }
        ui.finished -> PrimaryButton("Done") { act.onBack() }
        else -> PrimaryButton(if (n > 0) "CONFIRM ($n)" else "CONFIRM", enabled = any && n > 0) { act.onConfirmGroup() }
    }
    Spacer(Modifier.height(8.dp))
}
