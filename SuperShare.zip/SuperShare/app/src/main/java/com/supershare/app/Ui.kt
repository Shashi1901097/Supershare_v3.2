package com.supershare.app

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ---------------------------------------------------------------------------------------------
// Palette: deep midnight-indigo background, indigo cards, one gradient cyan -> blue -> violet
// ---------------------------------------------------------------------------------------------

val Charcoal = Color(0xFF0A0F2E)      // page colour (also the colour behind dialogs)
val Slate = Color(0xFF161F55)         // cards
val SlateHigh = Color(0xFF1F2A6E)
val Line = Color(0xFF2F3C8C)
val Cyan = Color(0xFF22D3EE)
val Pink = Color(0xFF4F8CFF)          // main accent (name kept from the old palette)
val Orange = Color(0xFF8B5CF6)        // second accent (violet)

val BrandBrush = Brush.horizontalGradient(listOf(Cyan, Pink, Orange))
val HeroBrush = Brush.linearGradient(listOf(Cyan, Pink, Orange))
val SendBrush = Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6)))
val ReceiveBrush = Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF22D3EE)))
val GroupBrush = Brush.linearGradient(listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)))
val FilesBrush = Brush.linearGradient(listOf(Color(0xFFFF9F43), Color(0xFFFF5E8A)))
/** Background of every page. */
val AppBg = Brush.verticalGradient(listOf(Color(0xFF060A22), Color(0xFF0E1646), Color(0xFF1A1470)))

private val BrandDark = darkColorScheme(
    primary = Pink, onPrimary = Color.White,
    primaryContainer = Color(0xFF1E2E6E), onPrimaryContainer = Color(0xFFD6E2FF),
    secondary = Orange, onSecondary = Color.White,
    secondaryContainer = Color(0xFF2A2F70), onSecondaryContainer = Color(0xFFE4E6FF),
    tertiary = Color(0xFF34D399), onTertiary = Color(0xFF00391F),
    tertiaryContainer = Color(0xFF123B38), onTertiaryContainer = Color(0xFFC4EED0),
    error = Color(0xFFFF7A8A), onError = Color(0xFF3A0000),
    errorContainer = Color(0xFF4A1A2E), onErrorContainer = Color(0xFFFFDAD6),
    background = Charcoal, onBackground = Color(0xFFF4F6FF),
    surface = Charcoal, onSurface = Color(0xFFF4F6FF),
    surfaceVariant = Color(0xFF232E78), onSurfaceVariant = Color(0xFFB4BCE6),
    outline = Color(0xFF5A66B0), outlineVariant = Line,
    surfaceContainerLowest = Color(0xFF070B26), surfaceContainerLow = Color(0xFF0F1745),
    surfaceContainer = Slate, surfaceContainerHigh = SlateHigh,
    surfaceContainerHighest = Color(0xFF28357F)
)

@Composable
fun SuperTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BrandDark) {
        // Gives every Text the light colour by default (the pages draw their own gradient, not a Surface).
        Surface(color = Color.Transparent, contentColor = MaterialTheme.colorScheme.onBackground, content = content)
    }
}

fun fmtSize(b: Long): String {
    val u = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < 4) { v /= 1024; i++ }
    return if (i == 0) "$b B" else "%.1f %s".format(v, u[i])
}

fun fmtEta(s: Long): String = when {
    s < 0 -> "—"
    s < 60 -> "${s}s"
    else -> "${s / 60}m ${s % 60}s"
}

// ---------------------------------------------------------------------------------------------
// Page structure
// ---------------------------------------------------------------------------------------------

@Composable
fun Screen(header: @Composable () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(AppBg)) {
        Column(Modifier.fillMaxSize()) {
            header()
            Column(Modifier.fillMaxSize().navigationBarsPadding().padding(horizontal = 20.dp), content = content)
        }
    }
}

/** Small vector icons drawn directly, so the app needs no icon library. */
@Composable
fun AppIcon(kind: String, tint: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        val w = s * 0.09f
        val st = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * s, y * s)
        when (kind) {
            "up" -> {
                drawLine(tint, p(0.5f, 0.82f), p(0.5f, 0.18f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.18f), p(0.24f, 0.44f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.18f), p(0.76f, 0.44f), w, StrokeCap.Round)
            }
            "down" -> {
                drawLine(tint, p(0.5f, 0.18f), p(0.5f, 0.82f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.82f), p(0.24f, 0.56f), w, StrokeCap.Round)
                drawLine(tint, p(0.5f, 0.82f), p(0.76f, 0.56f), w, StrokeCap.Round)
            }
            "back" -> drawPath(Path().apply { moveTo(0.62f * s, 0.2f * s); lineTo(0.34f * s, 0.5f * s); lineTo(0.62f * s, 0.8f * s) }, tint, style = st)
            "forward" -> drawPath(Path().apply { moveTo(0.38f * s, 0.2f * s); lineTo(0.66f * s, 0.5f * s); lineTo(0.38f * s, 0.8f * s) }, tint, style = st)
            "check" -> drawPath(Path().apply { moveTo(0.2f * s, 0.55f * s); lineTo(0.42f * s, 0.75f * s); lineTo(0.8f * s, 0.28f * s) }, tint, style = st)
            "folder" -> drawRoundRect(tint, topLeft = p(0.1f, 0.24f), size = Size(0.8f * s, 0.58f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
            "close" -> {
                drawLine(tint, p(0.26f, 0.26f), p(0.74f, 0.74f), w, StrokeCap.Round)
                drawLine(tint, p(0.74f, 0.26f), p(0.26f, 0.74f), w, StrokeCap.Round)
            }
            "search" -> {
                drawCircle(tint, radius = 0.25f * s, center = p(0.43f, 0.43f), style = st)
                drawLine(tint, p(0.62f, 0.62f), p(0.85f, 0.85f), w, StrokeCap.Round)
            }
            "video" -> {
                drawRoundRect(tint, topLeft = p(0.1f, 0.22f), size = Size(0.8f * s, 0.56f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
                drawPath(Path().apply { moveTo(0.43f * s, 0.36f * s); lineTo(0.43f * s, 0.64f * s); lineTo(0.65f * s, 0.5f * s); close() }, tint)
            }
            "android" -> {
                drawArc(tint, 180f, 180f, true, p(0.2f, 0.16f), Size(0.6f * s, 0.6f * s))
                drawRoundRect(tint, topLeft = p(0.2f, 0.6f), size = Size(0.6f * s, 0.24f * s), cornerRadius = CornerRadius(0.06f * s))
            }
            "photo" -> {
                drawRoundRect(tint, topLeft = p(0.1f, 0.2f), size = Size(0.8f * s, 0.6f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
                drawCircle(tint, radius = 0.07f * s, center = p(0.35f, 0.4f))
                drawPath(Path().apply { moveTo(0.16f * s, 0.74f * s); lineTo(0.42f * s, 0.5f * s); lineTo(0.58f * s, 0.64f * s); lineTo(0.7f * s, 0.54f * s); lineTo(0.84f * s, 0.7f * s) }, tint, style = st)
            }
            "audio" -> {
                drawLine(tint, p(0.6f, 0.2f), p(0.6f, 0.68f), w, StrokeCap.Round)
                drawLine(tint, p(0.6f, 0.2f), p(0.8f, 0.32f), w, StrokeCap.Round)
                drawCircle(tint, radius = 0.13f * s, center = p(0.46f, 0.7f))
            }
            "group" -> {
                drawCircle(tint, radius = 0.12f * s, center = p(0.37f, 0.34f), style = st)
                drawCircle(tint, radius = 0.1f * s, center = p(0.69f, 0.4f), style = st)
                drawArc(tint, 180f, 180f, false, p(0.12f, 0.6f), Size(0.5f * s, 0.36f * s), style = st)
                drawArc(tint, 180f, 180f, false, p(0.52f, 0.62f), Size(0.36f * s, 0.28f * s), style = st)
            }
            "phone" -> {
                drawRoundRect(tint, topLeft = p(0.3f, 0.08f), size = Size(0.4f * s, 0.84f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
                drawCircle(tint, radius = 0.035f * s, center = p(0.5f, 0.8f))
            }
            "tri" -> drawPath(Path().apply { moveTo(0.36f * s, 0.24f * s); lineTo(0.36f * s, 0.76f * s); lineTo(0.72f * s, 0.5f * s); close() }, tint)
            "tridown" -> drawPath(Path().apply { moveTo(0.24f * s, 0.36f * s); lineTo(0.76f * s, 0.36f * s); lineTo(0.5f * s, 0.72f * s); close() }, tint)
            "qr" -> {
                drawRoundRect(tint, topLeft = p(0.12f, 0.12f), size = Size(0.3f * s, 0.3f * s), cornerRadius = CornerRadius(0.04f * s), style = st)
                drawRoundRect(tint, topLeft = p(0.58f, 0.12f), size = Size(0.3f * s, 0.3f * s), cornerRadius = CornerRadius(0.04f * s), style = st)
                drawRoundRect(tint, topLeft = p(0.12f, 0.58f), size = Size(0.3f * s, 0.3f * s), cornerRadius = CornerRadius(0.04f * s), style = st)
                drawRect(tint, topLeft = p(0.6f, 0.6f), size = Size(0.12f * s, 0.12f * s))
                drawRect(tint, topLeft = p(0.78f, 0.78f), size = Size(0.1f * s, 0.1f * s))
            }
            else -> drawRoundRect(tint, topLeft = p(0.22f, 0.12f), size = Size(0.56f * s, 0.76f * s), cornerRadius = CornerRadius(0.08f * s), style = st)
        }
    }
}

@Composable
fun LogoTile(dim: Dp) {
    val shape = RoundedCornerShape(dim * 0.26f)
    Box(Modifier.size(dim).clip(shape).background(MaterialTheme.colorScheme.surfaceContainer).border(1.dp, Line, shape),
        contentAlignment = Alignment.Center) {
        Image(painter = painterResource(R.drawable.logo_ring), contentDescription = "Super Share logo",
            contentScale = ContentScale.Fit, modifier = Modifier.size(dim * 0.8f))
    }
}

/** The big logo with a soft glow behind it. */
@Composable
fun BigLogo(dim: Dp) {
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0x664F8CFF), Color.Transparent)), CircleShape))
        Image(painter = painterResource(R.drawable.logo_ring), contentDescription = "Super Share logo",
            contentScale = ContentScale.Fit, modifier = Modifier.size(dim * 0.78f))
    }
}

/** Two options side by side in one rounded pill (like a tab switch). Tapping an option calls [onSelect]. */
@Composable
fun PillOptions(options: List<String>, selected: Int, segmentHeight: Dp = 60.dp, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    Row(Modifier.fillMaxWidth().clip(shape)
        .background(Color.White.copy(alpha = 0.10f)).border(1.dp, Line, shape).padding(6.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(segmentHeight).clip(RoundedCornerShape(28.dp))
                    .then(if (on) Modifier.background(Brush.horizontalGradient(listOf(Color(0xFF2B4C9B), Color(0xFF3B3A9E)))) else Modifier)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                    color = if (on) Cyan else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** A wide, rounded, gradient button (Received files). */
@Composable
fun WideTile(title: String, icon: String, brush: Brush, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(modifier.fillMaxWidth().height(84.dp).shadow(10.dp, shape, ambientColor = Pink, spotColor = Pink).clip(shape)
        .background(brush).clickable(onClick = onClick).padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(50.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.24f)), contentAlignment = Alignment.Center) {
            AppIcon(icon, Color.White, 28.dp)
        }
        Spacer(Modifier.width(16.dp))
        Text(title, Modifier.weight(1f), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, letterSpacing = 0.5.sp)
        AppIcon("forward", Color.White, 22.dp)
    }
}

/** A square, rounded, gradient button (Send / Receive / Received files / One share / Group share). */
@Composable
fun SquareTile(title: String, icon: String, brush: Brush, modifier: Modifier = Modifier, sub: String = "", onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Box(modifier.aspectRatio(1f).shadow(12.dp, shape, ambientColor = Pink, spotColor = Pink).clip(shape).background(brush).clickable(onClick = onClick)) {
        Box(Modifier.align(Alignment.BottomEnd).offset(x = 22.dp, y = 22.dp)) { AppIcon(icon, Color.White.copy(alpha = 0.14f), 100.dp) }
        Column(Modifier.fillMaxSize().padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(64.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.24f)), contentAlignment = Alignment.Center) {
                AppIcon(icon, Color.White, 36.dp)
            }
            Spacer(Modifier.height(10.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, letterSpacing = 0.5.sp,
                textAlign = TextAlign.Center, maxLines = 2)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.85f), fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 2)
        }
    }
}

/** Top bar of every other screen. */
@Composable
fun Header(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)).clickable(onClick = onBack),
            contentAlignment = Alignment.Center) { AppIcon("back", MaterialTheme.colorScheme.onSurface, 22.dp) }
        Spacer(Modifier.width(14.dp))
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    }
}

// ---------------------------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------------------------

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(MaterialTheme.colorScheme.surfaceContainer).border(1.dp, Line, shape).padding(4.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp))
                    .then(if (on) Modifier.background(BrandBrush) else Modifier)
                    .clickable { if (!on) onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium,
                    color = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun PrimaryButton(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.fillMaxWidth().height(56.dp).alpha(if (enabled) 1f else 0.35f)
            .shadow(if (enabled) 8.dp else 0.dp, shape, ambientColor = Pink, spotColor = Pink)
            .clip(shape).background(BrandBrush).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}

/** Stop / cancel: quiet slate button with a red outline and label. */
@Composable
fun DangerButton(text: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        Modifier.fillMaxWidth().height(56.dp).clip(shape).background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f), shape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = MaterialTheme.colorScheme.error, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun SmallButton(text: String, danger: Boolean = false, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick, modifier = Modifier.height(36.dp), contentPadding = PaddingValues(horizontal = 14.dp),
        colors = if (danger) ButtonDefaults.filledTonalButtonColors(
            containerColor = MaterialTheme.colorScheme.errorContainer, contentColor = MaterialTheme.colorScheme.error)
        else ButtonDefaults.filledTonalButtonColors()
    ) { Text(text, style = MaterialTheme.typography.labelMedium) }
}

@Composable
fun fieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Pink, unfocusedBorderColor = Color(0xFF3A3A3A),
    focusedLabelColor = Pink, unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    cursorColor = Pink,
    focusedContainerColor = Slate, unfocusedContainerColor = Slate
)

@Composable
fun SurfaceCard(modifier: Modifier = Modifier, horizontalAlignment: Alignment.Horizontal = Alignment.Start,
                content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Card(modifier = modifier.fillMaxWidth().border(1.dp, Line, shape), shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(18.dp), horizontalAlignment = horizontalAlignment, content = content)
    }
}

/** The big gradient card for the main action. */
@Composable
fun HeroAction(title: String, icon: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    Box(modifier.fillMaxWidth().height(168.dp).shadow(10.dp, shape, ambientColor = Pink, spotColor = Pink)
        .clip(shape).background(HeroBrush).clickable(onClick = onClick)) {
        Box(Modifier.align(Alignment.BottomEnd).offset(x = 30.dp, y = 30.dp)) { AppIcon(icon, Color.White.copy(alpha = 0.16f), 170.dp) }
        Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
                AppIcon(icon, Color.White, 28.dp)
            }
            Text(title, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

/** A slate row-style action. */
@Composable
fun RowAction(title: String, icon: String, gradientIcon: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(MaterialTheme.colorScheme.surfaceContainer).border(1.dp, Line, shape)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(CircleShape).background(if (gradientIcon) BrandBrush else Brush.horizontalGradient(listOf(SlateHigh, SlateHigh))),
            contentAlignment = Alignment.Center
        ) { AppIcon(icon, if (gradientIcon) Color.White else MaterialTheme.colorScheme.onSurfaceVariant, 24.dp) }
        Spacer(Modifier.width(16.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        AppIcon("forward", MaterialTheme.colorScheme.onSurfaceVariant, 20.dp)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(text, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = modifier)
}

/** Round progress with a gradient arc; the speed sits in the middle. */
@Composable
fun Gauge(ui: UiState, dim: Dp) {
    val prog by animateFloatAsState(ui.progress, label = "progress")
    val track = MaterialTheme.colorScheme.surfaceContainerHigh
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 14.dp.toPx()
            val d = this.size.minDimension - sw
            val tl = Offset(sw / 2, sw / 2)
            drawArc(track, 0f, 360f, false, tl, Size(d, d), style = Stroke(sw))
            rotate(-90f) {
                drawArc(Brush.sweepGradient(listOf(Pink, Orange, Pink)), 0f, 360f * prog, false, tl, Size(d, d),
                    style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("%.0f".format(ui.mbps), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            Text("Mbps", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            Text("%.1f MB/s".format(ui.mbps / 8), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatColumn(label: String, value: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun Stats(ui: UiState) {
    val shape = RoundedCornerShape(18.dp)
    Card(Modifier.fillMaxWidth().border(1.dp, Line, shape), shape = shape,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 8.dp)) {
            StatColumn("Transferred", "${fmtSize(ui.done)} / ${fmtSize(ui.total)}", Modifier.weight(1.5f))
            StatColumn("Time left", fmtEta(ui.eta), Modifier.weight(1f))
            StatColumn("Peak", "%.0f Mbps".format(ui.peak), Modifier.weight(1f))
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Files and phones
// ---------------------------------------------------------------------------------------------

/** Colour per kind of file, like a file manager. */
fun typeColor(ext: String): Color = when (ext.lowercase()) {
    "apk", "aab", "xapk" -> Color(0xFF3DDC97)
    "zip", "rar", "7z", "gz", "tar", "tgz", "bz2", "xz" -> Color(0xFFFFB020)
    "pdf" -> Color(0xFFFF6B6B)
    "doc", "docx", "txt", "rtf", "odt" -> Color(0xFF5B9DFF)
    "xls", "xlsx", "csv", "ods" -> Color(0xFF34D399)
    "ppt", "pptx" -> Color(0xFFFF8A4C)
    "mp4", "mkv", "avi", "mov", "webm", "3gp" -> Color(0xFFB18CFF)
    "mp3", "flac", "wav", "aac", "ogg", "m4a" -> Color(0xFFFF7AB6)
    "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> Color(0xFF4DD0E1)
    else -> Color(0xFF9AA0AC)
}

@Composable
fun FileBadge(name: String, folder: Boolean = false) {
    val ext = if (folder) "" else name.substringAfterLast('.', "").take(4)
    val c = if (folder) Color(0xFFFFB020) else typeColor(ext)
    Box(Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(c.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
        if (folder) AppIcon("folder", c, 22.dp)
        else Text(ext.uppercase().ifEmpty { "FILE" }, style = MaterialTheme.typography.labelSmall, color = c,
            fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun Avatar(name: String) {
    Box(Modifier.size(44.dp).clip(CircleShape).background(BrandBrush), contentAlignment = Alignment.Center) {
        Text(name.trim().take(1).uppercase().ifEmpty { "?" }, color = Color.White, fontWeight = FontWeight.Bold,
            style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun FileRow(name: String, sub: String, modifier: Modifier = Modifier, trailing: @Composable () -> Unit = {}) {
    ListItem(
        modifier = modifier,
        headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium) },
        supportingContent = { Text(sub) },
        leadingContent = { FileBadge(name) },
        trailingContent = trailing,
        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
    )
}
